#define USE_FC_LEN_T
#include <string>
#include <stdio.h>
#include <limits>
#include "lbfgs.h"
#include "util.h"

#ifdef _OPENMP
#include <omp.h>
#endif

#include <R.h>
#include <Rmath.h>
#include <Rinternals.h>
#include <Rconfig.h>
#include <R_ext/Linpack.h>
#include <R_ext/Lapack.h>
#include <R_ext/BLAS.h>

#ifndef FCONE
#define FCONE
#endif

extern "C" {

    //Global variables

    double *X_nngp;
    double *y_nngp;

    int n_nngp;
    int p_nngp;
    int m_nngp;

    int covModel_nngp;
    int nThreads_nngp;

    double *D_nngp;
    int *D_sign_nngp;
    double *d_nngp;
    int *nnIndx_nngp;
    int *nnIndxLU_nngp;
    int *CIndx_nngp;


    int j_nngp;
    double eps_nngp;
    double fix_nugget_nngp;


    //covmodel = 0; exponential
    //covmodel = 1; spherical
    //covmodel = 2; matern
    //covmodel = 3; gaussian

    //Defining the likelihood (tausq/sigmasq = alphasq; phi = phi; nu = nu):


    //Update B and F:

    double updateBF(double *B, double *F, double *c, double *C, double *D, double *d, int *nnIndxLU, int *CIndx, int n, double *theta, int covModel, int nThreads, double fix_nugget){
        int i, k, l;
        int info = 0;
        int inc = 1;
        double one = 1.0;
        double zero = 0.0;
        char lower = 'L';
        double logDet = 0;
        double nu = 0;
        //check if the model is 'matern'
        if (covModel == 2) {
            nu = theta[2];
        }

        double *bk = (double *) R_alloc(nThreads*(static_cast<int>(1.0+5.0)), sizeof(double));


        //bk must be 1+(int)floor(alpha) * nthread
        int nb = 1+static_cast<int>(floor(5.0));
        int threadID = 0;

#ifdef _OPENMP
#pragma omp parallel for private(k, l, info, threadID)
#endif
        for(i = 0; i < n; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            //theta[0] = alphasquareIndex, theta[1] = phiIndex, theta[2] = nuIndex (in case of 'matern')
            if(i > 0){
                for(k = 0; k < nnIndxLU[n+i]; k++){
                    c[nnIndxLU[i]+k] = spCor(d[nnIndxLU[i]+k], theta[1], nu, covModel, &bk[threadID*nb]);
                    for(l = 0; l <= k; l++){
                        C[CIndx[i]+l*nnIndxLU[n+i]+k] = spCor(D[CIndx[i]+l*nnIndxLU[n+i]+k], theta[1], nu, covModel, &bk[threadID*nb]);
                        if(l == k){
                            C[CIndx[i]+l*nnIndxLU[n+i]+k] += theta[0]*fix_nugget;
                        }
                    }
                }
                F77_NAME(dpotrf)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
                F77_NAME(dpotri)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
                F77_NAME(dsymv)(&lower, &nnIndxLU[n+i], &one, &C[CIndx[i]], &nnIndxLU[n+i], &c[nnIndxLU[i]], &inc, &zero, &B[nnIndxLU[i]], &inc FCONE);
                F[i] = 1 - F77_NAME(ddot)(&nnIndxLU[n+i], &B[nnIndxLU[i]], &inc, &c[nnIndxLU[i]], &inc) + theta[0]*fix_nugget;
            }else{
                B[i] = 0;
                F[i] = 1+ theta[0]*fix_nugget;
            }
        }
        for(i = 0; i < n; i++){
            logDet += log(F[i]);
        }

        return(logDet);
    }

    void solve_B_F(double *B, double *F, double *norm_residual_boot, int n, int *nnIndxLU, int *nnIndx, double *residual_boot){

        residual_boot[0] = norm_residual_boot[0] * sqrt(F[0]);
        double sum;
        for (int i = 1; i < n; i++) {
            sum = norm_residual_boot[i];
            for (int l = 0; l < nnIndxLU[n + i]; l++) {
                sum = sum + B[nnIndxLU[i] + l] * residual_boot[nnIndx[nnIndxLU[i] + l]] / sqrt(F[i]);
            }
            residual_boot[i] = sum * sqrt(F[i]);
        }
    }



    void product_B_F(double *B, double *F, double *residual_nngp, int n, int *nnIndxLU, int *nnIndx, double *norm_residual_nngp){
        norm_residual_nngp[0] = residual_nngp[0]/sqrt(F[0]);
        double sum;
        for (int i = 1; i < n; i++) {
            sum = 0.0;
            for (int l = 0; l < nnIndxLU[n + i]; l++) {
                sum = sum - B[nnIndxLU[i] + l] * residual_nngp[nnIndx[nnIndxLU[i] + l]] / sqrt(F[i]);
            }
            norm_residual_nngp[i] = sum + residual_nngp[i] / sqrt(F[i]);
        }
    }


    double processed_output(double *X, double *y, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, int p, int m, double *theta, int covModel, int j, int nThreads, double optimized_likelihod, double *B, double *F, double *beta, double *Xbeta, double *norm_residual, double *theta_fp, double fix_nugget){

        char const *ntran = "N";
        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);
        double *c =(double *) R_alloc(nIndx, sizeof(double));
        double *C = (double *) R_alloc(j, sizeof(double)); zeros(C, j);

        double logDet;

        int pp = p*p;
        int info = 0;
        const double negOne = -1.0;
        const double one = 1.0;
        const double zero = 0.0;
        const int inc = 1;
        char const *lower = "L";


        double *tmp_pp = (double *) R_alloc(pp, sizeof(double));
        double *tmp_p = (double *) R_alloc(p, sizeof(double));
        double *tmp_n = (double *) R_alloc(n, sizeof(double));
        double *residual = (double *) R_alloc(n, sizeof(double));

        //create B and F
        logDet = updateBF(B, F, c, C, D, d, nnIndxLU, CIndx, n, theta, covModel, nThreads, fix_nugget);

        int i;
        for(i = 0; i < p; i++){
            tmp_p[i] = Q(B, F, &X[n*i], y, n, nnIndx, nnIndxLU);
            for(j = 0; j <= i; j++){
                tmp_pp[j*p+i] = Q(B, F, &X[n*j], &X[n*i], n, nnIndx, nnIndxLU);
            }
        }

        F77_NAME(dpotrf)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
        F77_NAME(dpotri)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}

        //create Beta
        F77_NAME(dsymv)(lower, &p, &one, tmp_pp, &p, tmp_p, &inc, &zero, beta, &inc FCONE);

        //create Xbeta
        F77_NAME(dgemv)(ntran, &n, &p, &one, X, &n, beta, &inc, &zero, tmp_n, &inc FCONE);

        dcopy_(&n, tmp_n, &inc, Xbeta, &inc);


        //create normalized residual
        F77_NAME(daxpy)(&n, &negOne, y, &inc, tmp_n, &inc);

        for (int s = 0; s < n; s++) {
            residual[s] = negOne * tmp_n[s];
        }

        product_B_F(B, F, residual, n, nnIndxLU, nnIndx, norm_residual);


        //Create complete theta

        // 1. Create sigma square
        theta_fp[0] = exp((optimized_likelihod - logDet)/n);


        // 2. Create tau square
        theta_fp[1] = theta[0] * theta_fp[0] * fix_nugget;

        // 3. Create phi
        theta_fp[2] = theta[1];

        // 4. Create nu in "matern"
        if (covModel == 2) {
            theta_fp[3] = theta[2];
        }

        return(optimized_likelihod);
    }



    //Defining likelihood in terms of theta.
    double likelihood(double *X, double *y, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, int p, int m, double *theta, int covModel, int j, int nThreads, double fix_nugget){

        char const *ntran = "N";
        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);
        double *B = (double *) R_alloc(nIndx, sizeof(double));
        double *F = (double *) R_alloc(n, sizeof(double));
        double *c =(double *) R_alloc(nIndx, sizeof(double));
        double *C = (double *) R_alloc(j, sizeof(double)); zeros(C, j);

        double logDet;

        int pp = p*p;
        int info = 0;
        double log_likelihood;
        const double negOne = -1.0;
        const double one = 1.0;
        const double zero = 0.0;
        const int inc = 1;
        char const *lower = "L";


        double *tmp_pp = (double *) R_alloc(pp, sizeof(double));
        double *tmp_p = (double *) R_alloc(p, sizeof(double));
        double *beta = (double *) R_alloc(p, sizeof(double));
        double *tmp_n = (double *) R_alloc(n, sizeof(double));

        logDet = updateBF(B, F, c, C, D, d, nnIndxLU, CIndx, n, theta, covModel, nThreads, fix_nugget);

        int i;
        for(i = 0; i < p; i++){
            tmp_p[i] = Q(B, F, &X[n*i], y, n, nnIndx, nnIndxLU);
            for(j = 0; j <= i; j++){
                tmp_pp[j*p+i] = Q(B, F, &X[n*j], &X[n*i], n, nnIndx, nnIndxLU);
            }
        }

        F77_NAME(dpotrf)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
        F77_NAME(dpotri)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
        F77_NAME(dsymv)(lower, &p, &one, tmp_pp, &p, tmp_p, &inc, &zero, beta, &inc FCONE);
        F77_NAME(dgemv)(ntran, &n, &p, &one, X, &n, beta, &inc, &zero, tmp_n, &inc FCONE);
        F77_NAME(daxpy)(&n, &negOne, y, &inc, tmp_n, &inc);

        //calculates likelihood
        log_likelihood = n * log(Q(B, F, tmp_n, tmp_n, n, nnIndx, nnIndxLU)/n) + logDet;

        return(log_likelihood);
    }



    //Defining likelihood w.r.t unconstrained optimization with alpha, root_phi, root_nu (in case of matern);

    // a. Non-matern models
    double likelihood_lbfgs_non_matern(double alpha, double root_phi, double *X, double *y, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, int p, int m, int covModel, int j, int nThreads, double fix_nugget){
        double *theta = (double *) R_alloc(2, sizeof(double));
        theta[0] = pow(alpha, 2.0);
        theta[1] = pow(root_phi, 2.0);
        double res = likelihood(X, y, D, d, nnIndx, nnIndxLU, CIndx, n, p, m, theta, covModel, j, nThreads, fix_nugget);//some unnecessary checking are happening here, will remove afterwards
        return(res);
    }


    //b. matern models
    double likelihood_lbfgs_matern(double alpha, double root_phi, double root_nu, double *X, double *y, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, int p, int m, int covModel, int j, int nThreads, double fix_nugget){
        double *theta = (double *) R_alloc(3, sizeof(double));
        theta[0] = pow(alpha, 2.0);
        theta[1] = pow(root_phi, 2.0);
        theta[2] = pow(root_nu, 2.0);
        double res = likelihood(X, y, D, d, nnIndx, nnIndxLU, CIndx, n, p, m, theta, covModel, j, nThreads, fix_nugget);//some unnecessary checking are happening here, will remove afterwards;
        return(res);
    }


    static lbfgsfloatval_t evaluate(
            void *instance,
            const lbfgsfloatval_t *x,
            lbfgsfloatval_t *g,
            const int n,
            const lbfgsfloatval_t step
    )
    {
        int i;
        lbfgsfloatval_t fx = 0.0;

        if (covModel_nngp != 2) {
            for (i = 0;i < n;i += 2) {
                g[i+1] = (likelihood_lbfgs_non_matern(x[i], (x[i+1]  + eps_nngp), X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp) - likelihood_lbfgs_non_matern(x[i], (x[i+1] - eps_nngp), X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp,fix_nugget_nngp))/(2*eps_nngp);

                g[i] = (likelihood_lbfgs_non_matern((x[i] + eps_nngp), x[i+1], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp) - likelihood_lbfgs_non_matern((x[i] - eps_nngp), x[i+1], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp,fix_nugget_nngp))/(2*eps_nngp);

                fx += likelihood_lbfgs_non_matern(x[i], x[i+1], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp,j_nngp, nThreads_nngp,fix_nugget_nngp);
            }
        } else {
            for (i = 0;i < n;i += 3) {
                g[i+1] = (likelihood_lbfgs_matern(x[i], (x[i+1]  + eps_nngp), x[i+2], X_nngp, ::y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp) - likelihood_lbfgs_matern(x[i], (x[i+1] - eps_nngp), x[i+2], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp))/(2*eps_nngp);

                g[i] = (likelihood_lbfgs_matern((x[i] + eps_nngp), x[i+1], x[i+2], X_nngp, ::y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp) - likelihood_lbfgs_matern((x[i] - eps_nngp), x[i+1], x[i+2], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp))/(2*eps_nngp);

                g[i+2] = (likelihood_lbfgs_matern(x[i], x[i+1], (x[i+2] + eps_nngp), X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp) - likelihood_lbfgs_matern(x[i], x[i+1], (x[i+2] - eps_nngp), X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp))/(2*eps_nngp);

                fx += likelihood_lbfgs_matern(x[i], x[i+1], x[i+2], X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, covModel_nngp, j_nngp, nThreads_nngp, fix_nugget_nngp);
            }
        }
        return fx;
    }

    void processed_bootstrap_output(double *X, double *y_boot, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, int p, int m, double *theta, int covModel, int j, int nThreads, double optimized_likelihod, double *beta_boot, double *theta_fp_boot, double fix_nugget){

        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);
        double *B = (double *) calloc(nIndx, sizeof(double));
        double *F = (double *) calloc(n, sizeof(double));
        double *c =(double *) calloc(nIndx, sizeof(double));
        double *C = (double *) calloc(j, sizeof(double)); zeros(C, j);

        double logDet;

        int pp = p*p;
        int info = 0;
        const double negOne = -1.0;
        const double one = 1.0;
        const double zero = 0.0;
        const int inc = 1;
        char const *lower = "L";


        double *tmp_pp = (double *) calloc(pp, sizeof(double));
        double *tmp_p = (double *) calloc(p, sizeof(double));
        double *tmp_n = (double *) calloc(n, sizeof(double));

        //create B and F
        logDet = updateBF(B, F, c, C, D, d, nnIndxLU, CIndx, n, theta, covModel, nThreads, fix_nugget);

        int i;
        for(i = 0; i < p; i++){
            tmp_p[i] = Q(B, F, &X[n*i], y_boot, n, nnIndx, nnIndxLU);
            for(j = 0; j <= i; j++){
                tmp_pp[j*p+i] = Q(B, F, &X[n*j], &X[n*i], n, nnIndx, nnIndxLU);
            }
        }

        F77_NAME(dpotrf)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
        F77_NAME(dpotri)(lower, &p, tmp_pp, &p, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}

        //create Beta
        F77_NAME(dsymv)(lower, &p, &one, tmp_pp, &p, tmp_p, &inc, &zero, beta_boot, &inc FCONE);


        //create residual
        F77_NAME(daxpy)(&n, &negOne, y_boot, &inc, tmp_n, &inc);



        //Create complete theta

        // 1. Create sigma square
        theta_fp_boot[0] = exp((optimized_likelihod - logDet)/n);


        // 2. Create tau square
        theta_fp_boot[1] = theta[0] * theta_fp_boot[0] * fix_nugget;

        // 3. Create phi
        theta_fp_boot[2] = theta[1];

        // 4. Create nu in "matern"
        if (covModel == 2) {
            theta_fp_boot[3] = theta[2];
        }

        free(B);
        free(F);
        free(c);
        free(C);
        free(tmp_pp);
        free(tmp_p);
        free(tmp_n);
    }

    SEXP process_bootstrap_data(SEXP B_r, SEXP F_r, SEXP Xbeta_r, SEXP norm_residual_boot_r, SEXP nnIndx_r, SEXP nnIndxLU_r, SEXP n_r, SEXP p_r){
        const int inc = 1;
        const double one = 1.0;
        n_nngp = INTEGER(n_r)[0];
        nnIndxLU_nngp = INTEGER(nnIndxLU_r);
        nnIndx_nngp = INTEGER(nnIndx_r);

        int nProtect = 0;

        SEXP residual_boot_r; PROTECT(residual_boot_r = allocVector(REALSXP, n_nngp)); nProtect++; double *residual_boot = REAL(residual_boot_r);

        solve_B_F(REAL(B_r), REAL(F_r), REAL(norm_residual_boot_r), n_nngp, INTEGER(nnIndxLU_r), INTEGER(nnIndx_r), residual_boot);

        //create y corresponding to boot
        F77_NAME(daxpy)(&n_nngp, &one, REAL(Xbeta_r), &inc, residual_boot, &inc);

        SEXP result_r, resultName_r;
        int nResultListObjs = 1;

        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, residual_boot_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("result"));


        namesgets(result_r, resultName_r);
        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }


    SEXP BRISC_bootstrapcpp(SEXP X_r, SEXP B_r, SEXP F_r, SEXP Xbeta_r, SEXP norm_residual_boot_r, SEXP D_r, SEXP d_r, SEXP nnIndx_r, SEXP nnIndxLU_r, SEXP CIndx_r, SEXP n_r, SEXP p_r, SEXP m_r, SEXP theta_r, SEXP covModel_r, SEXP j_r, SEXP nThreads_r, SEXP eps_r, SEXP fix_nugget_r){

        const int inc = 1;
        const double one = 1.0;
        X_nngp = REAL(X_r);
        p_nngp = INTEGER(p_r)[0];
        n_nngp = INTEGER(n_r)[0];
        double *theta_start = REAL(theta_r);
        D_nngp = REAL(D_r);
        d_nngp = REAL(d_r);
        nnIndxLU_nngp = INTEGER(nnIndxLU_r);
        nnIndx_nngp = INTEGER(nnIndx_r);
        CIndx_nngp = INTEGER(CIndx_r);
        j_nngp = INTEGER(j_r)[0];
        covModel_nngp = INTEGER(covModel_r)[0];
        nThreads_nngp = INTEGER(nThreads_r)[0];
        m_nngp = INTEGER(m_r)[0];
        eps_nngp = REAL(eps_r)[0];
        fix_nugget_nngp = REAL(fix_nugget_r)[0];


        int nProtect = 0;

        SEXP residual_boot_r; PROTECT(residual_boot_r = allocVector(REALSXP, n_nngp)); nProtect++; double *residual_boot = REAL(residual_boot_r);

        solve_B_F(REAL(B_r), REAL(F_r), REAL(norm_residual_boot_r), n_nngp, INTEGER(nnIndxLU_r), INTEGER(nnIndx_r), residual_boot);

        //create y corresponding to boot
        F77_NAME(daxpy)(&n_nngp, &one, REAL(Xbeta_r), &inc, residual_boot, &inc);

        y_nngp = residual_boot;

        int nTheta;

        if(covModel_nngp != 2){
            nTheta = 2;//tau^2 = 0, phi = 1
        }else{
            nTheta = 3;//tau^2 = 0, phi = 1, nu = 2;
        }

        int i_0, ret = 0;
        int k_0 = 0;
        lbfgsfloatval_t fx;
        lbfgsfloatval_t *x = lbfgs_malloc(nTheta);
        lbfgs_parameter_t param;

        /* Initialize the variables. */
        for (i_0 = 0;i_0 < nTheta; i_0++) {
            x[i_0] = theta_start[i_0];
        }

        /* Initialize the parameters for the L-BFGS optimization. */
        lbfgs_parameter_init(&param);
        param.epsilon = 1e-2;
        param.gtol = 0.9;
        /*param.linesearch = LBFGS_LINESEARCH_BACKTRACKING;*/

        /*
         Start the L-BFGS optimization; this will invoke the callback functions
         evaluate() and progress() when necessary.
         */
        ret = lbfgs(nTheta, x, &fx, evaluate, NULL, NULL, &param);

        // Construct output
        double *theta_boot = (double *) R_alloc(nTheta, sizeof(double));
        for (k_0 = 0; k_0 < nTheta; k_0++){
            theta_boot[k_0] = pow(x[k_0], 2.0);
        }

        // Clean up
        lbfgs_free(x);

        int nTheta_full = nTheta + 1;

        SEXP theta_fp_r; PROTECT(theta_fp_r = allocVector(REALSXP, nTheta_full)); nProtect++; double *theta_fp_boot = REAL(theta_fp_r);

        SEXP beta_r; PROTECT(beta_r = allocVector(REALSXP, p_nngp)); nProtect++; double *beta_boot = REAL(beta_r);

        processed_bootstrap_output(X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, theta_boot, covModel_nngp, j_nngp, nThreads_nngp, fx, beta_boot, theta_fp_boot, fix_nugget_nngp);

        SEXP result_r, resultName_r;
        int nResultListObjs = 2;

        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, theta_fp_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("theta"));

        SET_VECTOR_ELT(result_r, 1, beta_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("Beta"));

        namesgets(result_r, resultName_r);
        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }



    SEXP BRISC_estimatecpp(SEXP y_r, SEXP X_r, SEXP p_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP alphaSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r,
                           SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP eps_r, SEXP fix_nugget_r){

        int i, k, l, nProtect=0;

        //get args
        y_nngp = REAL(y_r);
        X_nngp = REAL(X_r);
        p_nngp = INTEGER(p_r)[0];
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        eps_nngp = REAL(eps_r)[0];
        fix_nugget_nngp = REAL(fix_nugget_r)[0];
        double *coords = REAL(coords_r);

        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);

        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];



#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("BRISC model fit with %i observations.\n\n", n_nngp);
            Rprintf("Number of covariates %i (including intercept if specified).\n\n", p_nngp);
            Rprintf("Using the %s spatial correlation model.\n\n", corName.c_str());
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }

        //parameters
        int nTheta;

        if(corName != "matern"){
            nTheta = 2;//tau^2 = 0, phi = 1
        }else{
            nTheta = 3;//tau^2 = 0, phi = 1, nu = 2;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));

        theta[0] = REAL(alphaSqStarting_r)[0];
        theta[1] = REAL(phiStarting_r)[0];

        if(corName == "matern"){
            theta[2] = REAL(nuStarting_r)[0];
        }

        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);

        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).

        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }else{
            mkNNIndxCB(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }


        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j_nngp = 0; i < n_nngp; i++){//zero should never be accessed
            j_nngp += nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
            if(i == 0){
                CIndx_nngp[n_nngp+i] = 0;
                CIndx_nngp[i] = 0;
            }else{
                CIndx_nngp[n_nngp+i] = nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
                CIndx_nngp[i] = CIndx_nngp[n_nngp+i-1] + CIndx_nngp[i-1];
            }
        }

        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;

        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);

        SEXP llk_r; PROTECT(llk_r = allocVector(REALSXP, 1)); nProtect++; double* llk_nngp = REAL(llk_r);

        for(i = 0; i < n_nngp; i++){
            for(k = 0; k < nnIndxLU_nngp[n_nngp+i]; k++){
                for(l = 0; l <= k; l++){
                    D_nngp[CIndx_nngp[i]+l*nnIndxLU_nngp[n_nngp+i]+k] = dist2(coords[nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[nnIndx_nngp[nnIndxLU_nngp[i]+l]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+l]]);
                }
            }
        }

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tPerforming optimization\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        int i_0, ret = 0;
        int k_0 = 0;
        lbfgsfloatval_t fx;
        lbfgsfloatval_t *x = lbfgs_malloc(nTheta);
        lbfgs_parameter_t param;

        /* Initialize the variables. */
        for (i_0 = 0;i_0 < nTheta; i_0++) {
            x[i_0] = theta[i_0];
        }

        /* Initialize the parameters for the L-BFGS optimization. */
        lbfgs_parameter_init(&param);
        param.epsilon = 1e-2;
        param.gtol = 0.9;
        /*param.linesearch = LBFGS_LINESEARCH_BACKTRACKING;*/

        /*
         Start the L-BFGS optimization; this will invoke the callback functions
         evaluate() and progress() when necessary.
         */
        ret = lbfgs(nTheta, x, &fx, evaluate, NULL, NULL, &param);

        // Construct output
        double *theta_nngp = (double *) R_alloc(nTheta, sizeof(double));
        for (k_0 = 0; k_0 < nTheta; k_0++){
            theta_nngp[k_0] = pow(x[k_0], 2.0);
        }

        // Clean up
        lbfgs_free(x);

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tProcessing optimizers\n");
            Rprintf("----------------------------------------\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        int nTheta_full = nTheta + 1;

        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);

        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);

        SEXP beta_r; PROTECT(beta_r = allocVector(REALSXP, p_nngp)); nProtect++; double *beta_nngp = REAL(beta_r);


        SEXP Xbeta_r; PROTECT(Xbeta_r = allocVector(REALSXP, n_nngp)); nProtect++; double *Xbeta_nngp = REAL(Xbeta_r);

        SEXP norm_residual_r; PROTECT(norm_residual_r = allocVector(REALSXP, n_nngp)); nProtect++; double *norm_residual_nngp = REAL(norm_residual_r);

        SEXP theta_fp_r; PROTECT(theta_fp_r = allocVector(REALSXP, nTheta_full)); nProtect++; double *theta_fp_nngp = REAL(theta_fp_r);

        llk_nngp[0] = processed_output(X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, theta_nngp, covModel_nngp, j_nngp, nThreads_nngp, fx, B_nngp, F_nngp, beta_nngp, Xbeta_nngp, norm_residual_nngp, theta_fp_nngp, fix_nugget_nngp);



        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 13;



        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, B_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("B"));

        SET_VECTOR_ELT(result_r, 1, F_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("F"));

        SET_VECTOR_ELT(result_r, 2, beta_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("Beta"));

        SET_VECTOR_ELT(result_r, 3, norm_residual_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("norm.residual"));

        SET_VECTOR_ELT(result_r, 4, theta_fp_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("theta"));


        SET_VECTOR_ELT(result_r, 5, Xbeta_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("Xbeta"));

        SET_VECTOR_ELT(result_r, 6, llk_r);
        SET_VECTOR_ELT(resultName_r, 6, mkChar("log_likelihood"));


        SET_VECTOR_ELT(result_r, 7, nnIndxLU_r);
        SET_VECTOR_ELT(resultName_r, 7, mkChar("nnIndxLU"));

        SET_VECTOR_ELT(result_r, 8, CIndx_r);
        SET_VECTOR_ELT(resultName_r, 8, mkChar("CIndx"));

        SET_VECTOR_ELT(result_r, 9, D_r);
        SET_VECTOR_ELT(resultName_r, 9, mkChar("D"));

        SET_VECTOR_ELT(result_r, 10, d_r);
        SET_VECTOR_ELT(resultName_r, 10, mkChar("d"));

        SET_VECTOR_ELT(result_r, 11, nnIndx_r);
        SET_VECTOR_ELT(resultName_r, 11, mkChar("nnIndx"));

        SET_VECTOR_ELT(result_r, 12, j_r);
        SET_VECTOR_ELT(resultName_r, 12, mkChar("Length.D"));



        namesgets(result_r, resultName_r);

        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }

    SEXP BRISC_correlationcpp(SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP alphaSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r,
                              SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP sim_number_r, SEXP fix_nugget_r){

        int i, j, k, l, nProtect=0;

        //get args
        int n = INTEGER(n_r)[0];
        int m = INTEGER(m_r)[0];
        double fix_nugget = REAL(fix_nugget_r)[0];
        double *coords = REAL(coords_r);

        int covModel = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel);

        int nThreads = INTEGER(nThreads_r)[0];
        int sim_number = INTEGER(sim_number_r)[0];
        double *sim = REAL(sim_r);
        int tot_length = n*sim_number;
        int verbose = INTEGER(verbose_r)[0];



#ifdef _OPENMP
        omp_set_num_threads(nThreads);
#else
        if(nThreads > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads);
            nThreads = 1;
        }
#endif

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("BRISC simulation with %i locations.\n\n", n);
            Rprintf("Using the %s spatial correlation model.\n\n", corName.c_str());
            Rprintf("Using %i nearest neighbors.\n\n", m);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }

        //parameters
        int nTheta;

        if(corName != "matern"){
            nTheta = 2;//tau^2 = 0, phi = 1
        }else{
            nTheta = 3;//tau^2 = 0, phi = 1, nu = 2;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));

        theta[0] = pow(REAL(alphaSqStarting_r)[0], 2.0);
        theta[1] = pow(REAL(phiStarting_r)[0], 2.0);

        if(corName == "matern"){
            theta[2] = pow(REAL(nuStarting_r)[0], 2.0);
        }

        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);

        int *nnIndx = (int *) R_alloc(nIndx, sizeof(int));

        double *d = (double *) R_alloc(nIndx, sizeof(double));

        int *nnIndxLU = (int *) R_alloc(2*n, sizeof(int));
        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n, m, coords, nnIndx, d, nnIndxLU);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n, m, coords, nnIndx, d, nnIndxLU);
        }else{
            mkNNIndxCB(n, m, coords, nnIndx, d, nnIndxLU);
        }



        int *CIndx = (int *) R_alloc(2*n, sizeof(int));
        for(i = 0, j = 0; i < n; i++){//zero should never be accessed
            j += nnIndxLU[n+i]*nnIndxLU[n+i];
            if(i == 0){
                CIndx[n+i] = 0;
                CIndx[i] = 0;
            }else{
                CIndx[n+i] = nnIndxLU[n+i]*nnIndxLU[n+i];
                CIndx[i] = CIndx[n+i-1] + CIndx[i-1];
            }
        }


        double *D = (double *) R_alloc(j, sizeof(double));

        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);

        for(i = 0; i < n; i++){
            for(k = 0; k < nnIndxLU[n+i]; k++){
                for(l = 0; l <= k; l++){
                    D[CIndx[i]+l*nnIndxLU[n+i]+k] = dist2(coords[nnIndx[nnIndxLU[i]+k]], coords[n+nnIndx[nnIndxLU[i]+k]], coords[nnIndx[nnIndxLU[i]+l]], coords[n+nnIndx[nnIndxLU[i]+l]]);
                }
            }
        }

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        double *B = (double *) R_alloc(nIndx, sizeof(double));
        double *F = (double *) R_alloc(n, sizeof(double));


        double *c =(double *) R_alloc(nIndx, sizeof(double));
        double *C = (double *) R_alloc(j, sizeof(double)); zeros(C, j);

        double logDet = updateBF(B, F, c, C, D, d, nnIndxLU, CIndx, n, theta, covModel, nThreads, fix_nugget);

        for(int im = 0; im < sim_number; im++){
            solve_B_F(B, F, &sim[n*im], n, nnIndxLU, nnIndx, &sim_cor[n*im]);
        }

        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 2;



        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, sim_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("norm_sim"));

        SET_VECTOR_ELT(result_r, 1, sim_cor_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("sim"));

        namesgets(result_r, resultName_r);

        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }





    SEXP BRISC_decorrelationcpp(SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP alphaSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r,
                                SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP sim_number_r, SEXP fix_nugget_r){

        int i, j, k, l, nProtect=0;

        //get args
        int n = INTEGER(n_r)[0];
        int m = INTEGER(m_r)[0];
        double fix_nugget = REAL(fix_nugget_r)[0];
        double *coords = REAL(coords_r);

        int covModel = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel);

        int nThreads = INTEGER(nThreads_r)[0];
        int sim_number = INTEGER(sim_number_r)[0];
        double *sim = REAL(sim_r);
        int tot_length = n*sim_number;
        int verbose = INTEGER(verbose_r)[0];



#ifdef _OPENMP
        omp_set_num_threads(nThreads);
#else
        if(nThreads > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads);
            nThreads = 1;
        }
#endif

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("BRISC simulation with %i locations.\n\n", n);
            Rprintf("Using the %s spatial correlation model.\n\n", corName.c_str());
            Rprintf("Using %i nearest neighbors.\n\n", m);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }

        //parameters
        int nTheta;

        if(corName != "matern"){
            nTheta = 2;//tau^2 = 0, phi = 1
        }else{
            nTheta = 3;//tau^2 = 0, phi = 1, nu = 2;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));

        theta[0] = pow(REAL(alphaSqStarting_r)[0], 2.0);
        theta[1] = pow(REAL(phiStarting_r)[0], 2.0);

        if(corName == "matern"){
            theta[2] = pow(REAL(nuStarting_r)[0], 2.0);
        }

        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);

        int *nnIndx = (int *) R_alloc(nIndx, sizeof(int));

        double *d = (double *) R_alloc(nIndx, sizeof(double));

        int *nnIndxLU = (int *) R_alloc(2*n, sizeof(int));

        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n, m, coords, nnIndx, d, nnIndxLU);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n, m, coords, nnIndx, d, nnIndxLU);
        }else{
            mkNNIndxCB(n, m, coords, nnIndx, d, nnIndxLU);
        }

        int *CIndx = (int *) R_alloc(2*n, sizeof(int));
        for(i = 0, j = 0; i < n; i++){//zero should never be accessed
            j += nnIndxLU[n+i]*nnIndxLU[n+i];
            if(i == 0){
                CIndx[n+i] = 0;
                CIndx[i] = 0;
            }else{
                CIndx[n+i] = nnIndxLU[n+i]*nnIndxLU[n+i];
                CIndx[i] = CIndx[n+i-1] + CIndx[i-1];
            }
        }

        double *D = (double *) R_alloc(j, sizeof(double));

        SEXP sim_decor_r; PROTECT(sim_decor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_decor = REAL(sim_decor_r);

        for(i = 0; i < n; i++){
            for(k = 0; k < nnIndxLU[n+i]; k++){
                for(l = 0; l <= k; l++){
                    D[CIndx[i]+l*nnIndxLU[n+i]+k] = dist2(coords[nnIndx[nnIndxLU[i]+k]], coords[n+nnIndx[nnIndxLU[i]+k]], coords[nnIndx[nnIndxLU[i]+l]], coords[n+nnIndx[nnIndxLU[i]+l]]);
                }
            }
        }

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        double *B = (double *) R_alloc(nIndx, sizeof(double));
        double *F = (double *) R_alloc(n, sizeof(double));

        double *c =(double *) R_alloc(nIndx, sizeof(double));
        double *C = (double *) R_alloc(j, sizeof(double)); zeros(C, j);

        double logDet = updateBF(B, F, c, C, D, d, nnIndxLU, CIndx, n, theta, covModel, nThreads, fix_nugget);

        for(int im = 0; im < sim_number; im++){
            product_B_F(B, F, &sim[n*im], n, nnIndxLU, nnIndx, &sim_decor[n*im]);
        }

        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 2;



        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, sim_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("sim"));

        SET_VECTOR_ELT(result_r, 1, sim_decor_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("residual_sim"));

        namesgets(result_r, resultName_r);

        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }


    SEXP BRISC_neighborcpp(SEXP n_r, SEXP m_r, SEXP coords_r,
                           SEXP sType_r, SEXP nThreads_r, SEXP verbose_r){

        int i, k, l, nProtect=0;

        //get args
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);

        std::string corName = getCorName(covModel_nngp);

        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];



#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }


        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);

        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).

        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }else{
            mkNNIndxCB(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }


        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j_nngp = 0; i < n_nngp; i++){//zero should never be accessed
            j_nngp += nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
            if(i == 0){
                CIndx_nngp[n_nngp+i] = 0;
                CIndx_nngp[i] = 0;
            }else{
                CIndx_nngp[n_nngp+i] = nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
                CIndx_nngp[i] = CIndx_nngp[n_nngp+i-1] + CIndx_nngp[i-1];
            }
        }

        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;

        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);

        for(i = 0; i < n_nngp; i++){
            for(k = 0; k < nnIndxLU_nngp[n_nngp+i]; k++){
                for(l = 0; l <= k; l++){
                    D_nngp[CIndx_nngp[i]+l*nnIndxLU_nngp[n_nngp+i]+k] = dist2(coords[nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[nnIndx_nngp[nnIndxLU_nngp[i]+l]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+l]]);
                }
            }
        }

        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 6;



        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;


        SET_VECTOR_ELT(result_r, 0, nnIndxLU_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("nnIndxLU"));

        SET_VECTOR_ELT(result_r, 1, CIndx_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("CIndx"));

        SET_VECTOR_ELT(result_r, 2, D_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("D"));

        SET_VECTOR_ELT(result_r, 3, d_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("d"));

        SET_VECTOR_ELT(result_r, 4, nnIndx_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("nnIndx"));

        SET_VECTOR_ELT(result_r, 5, j_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("Length.D"));


        namesgets(result_r, resultName_r);

        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }

    SEXP BRISC_estimateneighborcpp(SEXP y_r, SEXP X_r, SEXP p_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP alphaSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r,
                           SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP eps_r, SEXP fix_nugget_r,
                                       SEXP nnIndxLU_r, SEXP CIndx_r, SEXP D_r, SEXP d_r, SEXP nnIndx_r, SEXP j_r){

        int i, k, l, nProtect=0;

        //get args
        y_nngp = REAL(y_r);
        X_nngp = REAL(X_r);
        p_nngp = INTEGER(p_r)[0];
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        eps_nngp = REAL(eps_r)[0];
        fix_nugget_nngp = REAL(fix_nugget_r)[0];
        double *coords = REAL(coords_r);

        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);

        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];



#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("BRISC model fit with %i observations.\n\n", n_nngp);
            Rprintf("Number of covariates %i (including intercept if specified).\n\n", p_nngp);
            Rprintf("Using the %s spatial correlation model.\n\n", corName.c_str());
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }

        //parameters
        int nTheta;

        if(corName != "matern"){
            nTheta = 2;//tau^2 = 0, phi = 1
        }else{
            nTheta = 3;//tau^2 = 0, phi = 1, nu = 2;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));

        theta[0] = REAL(alphaSqStarting_r)[0];
        theta[1] = REAL(phiStarting_r)[0];

        if(corName == "matern"){
            theta[2] = REAL(nuStarting_r)[0];
        }

        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        nnIndx_nngp = INTEGER(nnIndx_r);
        d_nngp = REAL(d_r);

        nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).


        CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        INTEGER(j_r)[0] = j_nngp;

        D_nngp = REAL(D_r);

        SEXP llk_r; PROTECT(llk_r = allocVector(REALSXP, 1)); nProtect++; double* llk_nngp = REAL(llk_r);

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tPerforming optimization\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        int i_0, ret = 0;
        int k_0 = 0;
        lbfgsfloatval_t fx;
        lbfgsfloatval_t *x = lbfgs_malloc(nTheta);
        lbfgs_parameter_t param;

        /* Initialize the variables. */
        for (i_0 = 0;i_0 < nTheta; i_0++) {
            x[i_0] = theta[i_0];
        }

        /* Initialize the parameters for the L-BFGS optimization. */
        lbfgs_parameter_init(&param);
        param.epsilon = 1e-2;
        param.gtol = 0.9;
        /*param.linesearch = LBFGS_LINESEARCH_BACKTRACKING;*/

        /*
         Start the L-BFGS optimization; this will invoke the callback functions
         evaluate() and progress() when necessary.
         */
        ret = lbfgs(nTheta, x, &fx, evaluate, NULL, NULL, &param);

        // Construct output
        double *theta_nngp = (double *) R_alloc(nTheta, sizeof(double));
        for (k_0 = 0; k_0 < nTheta; k_0++){
            theta_nngp[k_0] = pow(x[k_0], 2.0);
        }

        // Clean up
        lbfgs_free(x);

        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tProcessing optimizers\n");
            Rprintf("----------------------------------------\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }

        int nTheta_full = nTheta + 1;

        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);

        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);

        SEXP beta_r; PROTECT(beta_r = allocVector(REALSXP, p_nngp)); nProtect++; double *beta_nngp = REAL(beta_r);


        SEXP Xbeta_r; PROTECT(Xbeta_r = allocVector(REALSXP, n_nngp)); nProtect++; double *Xbeta_nngp = REAL(Xbeta_r);

        SEXP norm_residual_r; PROTECT(norm_residual_r = allocVector(REALSXP, n_nngp)); nProtect++; double *norm_residual_nngp = REAL(norm_residual_r);

        SEXP theta_fp_r; PROTECT(theta_fp_r = allocVector(REALSXP, nTheta_full)); nProtect++; double *theta_fp_nngp = REAL(theta_fp_r);

        llk_nngp[0] = processed_output(X_nngp, y_nngp, D_nngp, d_nngp, nnIndx_nngp, nnIndxLU_nngp, CIndx_nngp, n_nngp, p_nngp, m_nngp, theta_nngp, covModel_nngp, j_nngp, nThreads_nngp, fx, B_nngp, F_nngp, beta_nngp, Xbeta_nngp, norm_residual_nngp, theta_fp_nngp, fix_nugget_nngp);



        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 7;



        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;

        SET_VECTOR_ELT(result_r, 0, B_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("B"));

        SET_VECTOR_ELT(result_r, 1, F_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("F"));

        SET_VECTOR_ELT(result_r, 2, beta_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("Beta"));

        SET_VECTOR_ELT(result_r, 3, norm_residual_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("norm.residual"));

        SET_VECTOR_ELT(result_r, 4, theta_fp_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("theta"));


        SET_VECTOR_ELT(result_r, 5, Xbeta_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("Xbeta"));


        SET_VECTOR_ELT(result_r, 6, llk_r);
        SET_VECTOR_ELT(resultName_r, 6, mkChar("log_likelihood"));


        namesgets(result_r, resultName_r);

        //unprotect
        UNPROTECT(nProtect);


        return(result_r);
    }
    
    
    double updateBF_binary(double *y, double *B, double *F, double *c, double *C, double *D, double *d, int *nnIndx, int *nnIndxLU, int *CIndx, int n, double *theta, int covModel, int nThreads){
        int i, k, l;
        int info = 0;
        int inc = 1;
        double one = 1.0;
        double zero = 0.0;
        char lower = 'L';
        double logDet = 0;
        double nu = 0;
        //check if the model is 'matern'
        if (covModel == 2) {
            nu = theta[3];
        }
        
        double *bk = (double *) R_alloc(nThreads*(static_cast<int>(1.0+5.0)), sizeof(double));
        
        
        //bk must be 1+(int)floor(alpha) * nthread
        int nb = 1+static_cast<int>(floor(5.0));
        int threadID = 0;
        
#ifdef _OPENMP
#pragma omp parallel for private(k, l, info, threadID)
#endif
        for(i = 0; i < n; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            //theta[0] = sigmasquareIndex, theta[1] = tausquareIndex,, theta[2] = phiIndex, theta[3] = nuIndex (in case of 'matern')
            if(i > 0){
                for(k = 0; k < nnIndxLU[n+i]; k++){
                    c[nnIndxLU[i]+k] = (2 * y[nnIndx[nnIndxLU[i]+k]] - 1) * (2 * y[i] - 1) * theta[0] * spCor(d[nnIndxLU[i]+k], theta[2], nu, covModel, &bk[threadID*nb]);
                    for(l = 0; l <= k; l++){
                        C[CIndx[i]+l*nnIndxLU[n+i]+k] = (2 * y[nnIndx[nnIndxLU[i]+k]] - 1) * (2 * y[nnIndx[nnIndxLU[i]+l]] - 1) * theta[0] * spCor(D[CIndx[i]+l*nnIndxLU[n+i]+k], theta[2], nu, covModel, &bk[threadID*nb]);
                        if(l == k){
                            C[CIndx[i]+l*nnIndxLU[n+i]+k] += 1 + (2 * y[nnIndx[nnIndxLU[i]+k]] - 1) * (2 * y[nnIndx[nnIndxLU[i]+l]] - 1) * theta[1];
                        }
                    }
                }
                F77_NAME(dpotrf)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
                F77_NAME(dpotri)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
                F77_NAME(dsymv)(&lower, &nnIndxLU[n+i], &one, &C[CIndx[i]], &nnIndxLU[n+i], &c[nnIndxLU[i]], &inc, &zero, &B[nnIndxLU[i]], &inc FCONE);
                F[i] = (2 * y[i] - 1) * (theta[1] + theta[0]) * (2 * y[i] - 1) + 1 - F77_NAME(ddot)(&nnIndxLU[n+i], &B[nnIndxLU[i]], &inc, &c[nnIndxLU[i]], &inc);
            }else{
                B[i] = 0;
                F[i] = (2 * y[i] - 1) * (theta[1]+ theta[0]) * (2 * y[i] - 1);
            }
        }
        for(i = 0; i < n; i++){
            logDet += log(F[i]);
        }
        
        return(logDet);
    }
    
    
    double binary_updateBF(double *y, double *B, double *F, double *c, double *C, double *D, double *d, int *nnIndxLU, int *nnIndx, int *CIndx, int n, double *theta, int covModel, int nThreads){
        int i, k, l;
        int info = 0;
        int inc = 1;
        double one = 1.0;
        double zero = 0.0;
        char lower = 'L';
        double logDet = 0;
        double nu = 0;
        //check if the model is 'matern'
        if (covModel == 2) {
            nu = theta[3];
        }
        
        double *bk = (double *) R_alloc(nThreads*(static_cast<int>(1.0+5.0)), sizeof(double));
        
        
        //bk must be 1+(int)floor(alpha) * nthread
        int nb = 1+static_cast<int>(floor(5.0));
        int threadID = 0;
        
#ifdef _OPENMP
#pragma omp parallel for private(k, l, info, threadID)
#endif
        for(i = 0; i < n; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            //theta[0] = alphasquareIndex, theta[1] = phiIndex, theta[2] = nuIndex (in case of 'matern')
            if(i > 0){
                for(k = 0; k < nnIndxLU[n+i]; k++){
                    c[nnIndxLU[i]+k] = (2 * y[nnIndx[nnIndxLU[i]+k]] - 1) * (2 * y[i] - 1) * theta[0] * spCor(d[nnIndxLU[i]+k], theta[2], nu, covModel, &bk[threadID*nb]);
                    for(l = 0; l <= k; l++){
                        C[CIndx[i]+l*nnIndxLU[n+i]+k] = (2 * y[nnIndx[nnIndxLU[i]+k]] - 1) * (2 * y[nnIndx[nnIndxLU[i]+l]] - 1) * theta[0] * spCor(D[CIndx[i]+l*nnIndxLU[n+i]+k], theta[2], nu, covModel, &bk[threadID*nb]);
                        if(l == k){
                            C[CIndx[i]+l*nnIndxLU[n+i]+k] += 1 + theta[1];
                        }
                    }
                }
                F77_NAME(dpotrf)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
                F77_NAME(dpotri)(&lower, &nnIndxLU[n+i], &C[CIndx[i]], &nnIndxLU[n+i], &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
                F77_NAME(dsymv)(&lower, &nnIndxLU[n+i], &one, &C[CIndx[i]], &nnIndxLU[n+i], &c[nnIndxLU[i]], &inc, &zero, &B[nnIndxLU[i]], &inc FCONE);
                F[i] = 1 + theta[0] + theta[1] - F77_NAME(ddot)(&nnIndxLU[n+i], &B[nnIndxLU[i]], &inc, &c[nnIndxLU[i]], &inc);
            }else{
                B[i] = 0;
                F[i] = 1 + theta[0] + theta[1];
            }
        }
        for(i = 0; i < n; i++){
            logDet += log(F[i]);
        }
        
        return(logDet);
    }
    
    SEXP Binary_prediction_cholesky_cpp_org(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                              SEXP sType_r, SEXP nThreads_r, SEXP verbose_r){
        
        int i, j, k, l, nProtect=0;
        
        //get args
        double *y = REAL(y_r);
        int n = INTEGER(n_r)[0];
        int m = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        
        int covModel = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel);
        
        int nThreads = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads);
#else
        if(nThreads > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads);
            nThreads = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("BRISC model fit with %i observations.\n\n", n);
            Rprintf("Using the %s spatial correlation model.\n\n", corName.c_str());
            Rprintf("Using %i nearest neighbors.\n\n", m);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];

        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m)/2*m+(n-m-1)*m);
        
        //int *nnIndx = (int *) R_alloc(nIndx, sizeof(int));
        
        //double *d = (double *) R_alloc(nIndx, sizeof(double));
        
        //int *nnIndxLU = (int *) R_alloc(2*n, sizeof(int));
        
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; int *nnIndx = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; double *d = REAL(d_r);
        
        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; int *nnIndxLU = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n, m, coords, nnIndx, d, nnIndxLU);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n, m, coords, nnIndx, d, nnIndxLU);
        }else{
            mkNNIndxCB(n, m, coords, nnIndx, d, nnIndxLU);
        }
        
        
        
        //int *CIndx = (int *) R_alloc(2*n, sizeof(int));
        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; int *CIndx = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j = 0; i < n; i++){//zero should never be accessed
            j += nnIndxLU[n+i]*nnIndxLU[n+i];
            if(i == 0){
                CIndx[n+i] = 0;
                CIndx[i] = 0;
            }else{
                CIndx[n+i] = nnIndxLU[n+i]*nnIndxLU[n+i];
                CIndx[i] = CIndx[n+i-1] + CIndx[i-1];
            }
        }
        
        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j;
        
        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; double *D = REAL(D_r);
        
        //double *D = (double *) R_alloc(j, sizeof(double));
        
        
        for(i = 0; i < n; i++){
            for(k = 0; k < nnIndxLU[n+i]; k++){
                for(l = 0; l <= k; l++){
                    D[CIndx[i]+l*nnIndxLU[n+i]+k] = dist2(coords[nnIndx[nnIndxLU[i]+k]], coords[n+nnIndx[nnIndxLU[i]+k]], coords[nnIndx[nnIndxLU[i]+l]], coords[n+nnIndx[nnIndxLU[i]+l]]);
                }
            }
        }
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        //double *B = (double *) R_alloc(nIndx, sizeof(double));
        //double *F = (double *) R_alloc(n, sizeof(double));
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F = REAL(F_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j, sizeof(double)); zeros(C, j);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j)); nProtect++; double *C = REAL(C_r);
        
        double logDet = updateBF_binary(y, B, F, c, C, D, d, nnIndx, nnIndxLU, CIndx, n, theta, covModel, nThreads);
        
        
        SEXP result_r, resultName_r;
        int nResultListObjs = 8;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        SET_VECTOR_ELT(result_r, 0, nnIndxLU_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("nnIndxLU"));
        
        SET_VECTOR_ELT(result_r, 1, CIndx_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("CIndx"));
        
        SET_VECTOR_ELT(result_r, 2, D_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("D"));
        
        SET_VECTOR_ELT(result_r, 3, d_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("d"));
        
        SET_VECTOR_ELT(result_r, 4, nnIndx_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("nnIndx"));
        
        SET_VECTOR_ELT(result_r, 5, j_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("Length.D"));
        
        SET_VECTOR_ELT(result_r, 6, B_r);
        SET_VECTOR_ELT(resultName_r, 6, mkChar("B"));
        
        SET_VECTOR_ELT(result_r, 7, F_r);
        SET_VECTOR_ELT(resultName_r, 7, mkChar("F"));
        
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
    
    
    double eval_binary_e(double *u, double *mhat, double *L, int n, double *e){
        
        e[0] = pnorm(mhat[0]/L[0], 0.0, 1.0, 1, 0);
        double e_prod = e[0];
        double sum;
        for (int i = 1; i < n; i++) {
            sum = 0.0;
            for (int j = 0; j < i; j++) {
                sum = sum + L[(i - 1) + n*j + 1 ] * qnorm(u[j] * e[j], 0.0, 1.0, 1, 0);
            }
            e[i] = pnorm((mhat[i] - sum)/L[i * n + i], 0.0, 1.0, 1, 0);
            e_prod = e_prod * e[i];
        }
        return(e_prod);
    }
    
    void solve_B_F_predict2(double *B, double F, int n, int *nnindx0, int m_nngp, double *residual_boot, double *L, int i0, int q){
        
        double sum;
        for (int i = 0; i < n; i++) {
            sum = 0.0;
            for (int l = 0; l < m_nngp; l++) {
                sum = sum + B[l] * L[(nnindx0[i0 + q * l] - 1) + n*i + 1 ] / sqrt(F);
            }
            residual_boot[i] = sum * sqrt(F);
        }
    }
    
    
    SEXP Binary_prediction_cholesky_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                        SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        int sim_number = n_nngp;
        double *sim = REAL(sim_r);
        int tot_length = n_nngp*sim_number;
        
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);
        
        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }else{
            mkNNIndxCB(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        
        
        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j_nngp = 0; i < n_nngp; i++){//zero should never be accessed
            j_nngp += nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
            if(i == 0){
                CIndx_nngp[n_nngp+i] = 0;
                CIndx_nngp[i] = 0;
            }else{
                CIndx_nngp[n_nngp+i] = nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
                CIndx_nngp[i] = CIndx_nngp[n_nngp+i-1] + CIndx_nngp[i-1];
            }
        }
        
        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;
        
        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);
        
        //SEXP D_sign_r; PROTECT(D_sign_r = allocVector(INTSXP, j_nngp)); nProtect++; D_sign_nngp = INTEGER(D_sign_r);
        
        for(i = 0; i < n_nngp; i++){
            for(k = 0; k < nnIndxLU_nngp[n_nngp+i]; k++){
                for(l = 0; l <= k; l++){
                    D_nngp[CIndx_nngp[i]+l*nnIndxLU_nngp[n_nngp+i]+k] = dist2(coords[nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[nnIndx_nngp[nnIndxLU_nngp[i]+l]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+l]]);
                }
            }
        }
        
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j_nngp)); nProtect++; double *C = REAL(C_r);
        
        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j_nngp, sizeof(double)); zeros(C, j_nngp);
        
        
        double logDet = binary_updateBF(y_nngp, B_nngp, F_nngp, c, C, D_nngp, d_nngp, nnIndxLU_nngp, nnIndx_nngp, CIndx_nngp, n_nngp, theta, covModel_nngp, nThreads_nngp);
        
        for(int im = 0; im < sim_number; im++){
            solve_B_F(B_nngp, F_nngp, &sim[n_nngp*im], n_nngp, nnIndxLU_nngp, nnIndx_nngp, &sim_cor[n_nngp*im]);
        }
        
        
        
        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 11;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        SET_VECTOR_ELT(result_r, 0, nnIndxLU_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("nnIndxLU"));
        
        SET_VECTOR_ELT(result_r, 1, CIndx_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("CIndx"));
        
        SET_VECTOR_ELT(result_r, 2, D_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("D"));
        
        SET_VECTOR_ELT(result_r, 3, d_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("d"));
        
        SET_VECTOR_ELT(result_r, 4, nnIndx_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("nnIndx"));
        
        SET_VECTOR_ELT(result_r, 5, sim_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("sim_org"));
        
        SET_VECTOR_ELT(result_r, 6, B_r);
        SET_VECTOR_ELT(resultName_r, 6, mkChar("B"));
        
        SET_VECTOR_ELT(result_r, 7, F_r);
        SET_VECTOR_ELT(resultName_r, 7, mkChar("F"));
        
        SET_VECTOR_ELT(result_r, 8, c_r);
        SET_VECTOR_ELT(resultName_r, 8, mkChar("c"));
        
        SET_VECTOR_ELT(result_r, 9, C_r);
        SET_VECTOR_ELT(resultName_r, 9, mkChar("C"));
        
        SET_VECTOR_ELT(result_r, 10, sim_cor_r);
        SET_VECTOR_ELT(resultName_r, 10, mkChar("sim"));
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
    
    
    SEXP Binary_prediction_cholesky_prediction_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                                   SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP mvec_r, SEXP unif_eval_r, SEXP mc_r, SEXP coords0_r, SEXP q_r, SEXP nnIndx0_r, SEXP mvec0_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        int sim_number = n_nngp;
        double *sim = REAL(sim_r);
        int tot_length = n_nngp*sim_number;
        double *unif_eval = REAL(unif_eval_r);
        double *mvec = REAL(mvec_r);
        int mc = INTEGER(mc_r)[0];
        double *mvec0 = REAL(mvec0_r);
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);
        
        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }else{
            mkNNIndxCB(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        
        
        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j_nngp = 0; i < n_nngp; i++){//zero should never be accessed
            j_nngp += nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
            if(i == 0){
                CIndx_nngp[n_nngp+i] = 0;
                CIndx_nngp[i] = 0;
            }else{
                CIndx_nngp[n_nngp+i] = nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
                CIndx_nngp[i] = CIndx_nngp[n_nngp+i-1] + CIndx_nngp[i-1];
            }
        }
        
        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;
        
        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);
        
        //SEXP D_sign_r; PROTECT(D_sign_r = allocVector(INTSXP, j_nngp)); nProtect++; D_sign_nngp = INTEGER(D_sign_r);
        
        for(i = 0; i < n_nngp; i++){
            for(k = 0; k < nnIndxLU_nngp[n_nngp+i]; k++){
                for(l = 0; l <= k; l++){
                    D_nngp[CIndx_nngp[i]+l*nnIndxLU_nngp[n_nngp+i]+k] = dist2(coords[nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[nnIndx_nngp[nnIndxLU_nngp[i]+l]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+l]]);
                }
            }
        }
        
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j_nngp)); nProtect++; double *C = REAL(C_r);
        
        //SEXP e_prod_r; PROTECT(e_prod_r = allocMatrix(REALSXP, mc, 2)); nProtect++; double *e_prod = REAL(e_prod_r);
        SEXP e_prod_r; PROTECT(e_prod_r = allocVector(REALSXP, mc)); nProtect++; double *e_prod = REAL(e_prod_r);
        
        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j_nngp, sizeof(double)); zeros(C, j_nngp);
        
        
        double logDet = binary_updateBF(y_nngp, B_nngp, F_nngp, c, C, D_nngp, d_nngp, nnIndxLU_nngp, nnIndx_nngp, CIndx_nngp, n_nngp, theta, covModel_nngp, nThreads_nngp);
        
        for(int im = 0; im < sim_number; im++){//need to parallel
            solve_B_F(B_nngp, F_nngp, &sim[n_nngp*im], n_nngp, nnIndxLU_nngp, nnIndx_nngp, &sim_cor[n_nngp*im]);
        }
        
        //double *e =(double *) R_alloc(mc*n_nngp, sizeof(double));
        SEXP e_r; PROTECT(e_r = allocMatrix(REALSXP, n_nngp, mc)); nProtect++; double *e = REAL(e_r);
        for(int im = 0; im < mc; im++){//need to parallel
            e_prod[im] = eval_binary_e(&unif_eval[n_nngp*im], mvec, sim_cor, n_nngp, &e[n_nngp*im]);
        }
        
        //prediction
        double *coords0 = REAL(coords0_r);
        int q = INTEGER(q_r)[0];
        
        int *nnIndx0 = INTEGER(nnIndx0_r);
        
        const int inc = 1;
        const double one = 1.0;
        const double zero = 0.0;
        char const *lower = "L";
        int info, j, im;
        double sum;
        
        //parameters
        int sigmaSqIndx, tauSqIndx, phiIndx, nuIndx;
        
        if(corName != "matern"){
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2;
        }else{
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2; nuIndx = 3;
        }
        
        //get max nu
        double nuMax = 0;
        int nb = 0;
        
        if(corName == "matern"){
            if(theta[nuIndx] > nb){
                nb = theta[nuIndx];
            }
            
            nb = 1+static_cast<int>(floor(nuMax));
        }
        
        double *bk = (double *) R_alloc(nThreads_nngp*nb, sizeof(double));
        int mm = m_nngp*m_nngp;
        
        //SEXP c_predict_r; PROTECT(c_predict_r = allocVector(REALSXP, nThreads_nngp*m_nngp)); nProtect++; double *c_predict = REAL(c_r);
        
        //SEXP C_predict_r; PROTECT(C_predict_r = allocVector(REALSXP, nThreads_nngp*mm)); nProtect++; double *C_predict = REAL(C_r);
        //zeros(C_predict, nThreads_nngp*mm);
        //zeros(c_predict, nThreads_nngp*m_nngp);
        
        double *C_predict = (double *) R_alloc(nThreads_nngp*mm, sizeof(double)); zeros(C_predict, nThreads_nngp*mm);
        double *c_predict = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double)); zeros(c_predict, nThreads_nngp*m_nngp);
        //SEXP L_pred_r; PROTECT(L_pred_r = allocVector(REALSXP, q * (1 + n_nngp))); nProtect++; double *L_pred = REAL(L_pred_r);
        
        double *tmp_m  = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double));
        double phi = 0, nu = 0, sigmaSq = 0, tauSq = 0, d;
        int threadID = 0;
        
        SEXP y0_r;
        SEXP vary0_r;
        SEXP L0_r;
        PROTECT(vary0_r = allocMatrix(REALSXP, q, 1)); nProtect++;
        double *vary0 = REAL(vary0_r);
        PROTECT(y0_r = allocMatrix(REALSXP, m_nngp, q)); nProtect++;
        double *y0 = REAL(y0_r);
        PROTECT(L0_r = allocMatrix(REALSXP, n_nngp, q)); nProtect++;
        double *L0 = REAL(L0_r);
        SEXP e_pred_r; PROTECT(e_pred_r = allocMatrix(REALSXP, mc, q)); nProtect++; double *e_pred = REAL(e_pred_r);
        
        
        if(verbose){
            Rprintf("-------------------------------------------------\n");
            Rprintf("\t\tBuilding prediction cholesky\n");
            Rprintf("-------------------------------------------------\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        
        
        
#ifdef _OPENMP
#pragma omp parallel for private(threadID, phi, nu, sigmaSq, tauSq, k, l, d, info, sum, j, im)
#endif
        for(i = 0; i < q; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            phi = theta[phiIndx];
            if(corName == "matern"){
                nu = theta[nuIndx];
            }
            sigmaSq = theta[sigmaSqIndx];
            tauSq = theta[tauSqIndx];
            
            for(k = 0; k < m_nngp; k++){
                d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords0[i], coords0[q+i]);
                c_predict[threadID*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                for(l = 0; l < m_nngp; l++){
                    d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords[nnIndx0[i+q*l]], coords[n_nngp+nnIndx0[i+q*l]]);
                    C_predict[threadID*mm+l*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * (2 * y_nngp[nnIndx0[i+q*l]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                    if(k == l){
                        C_predict[threadID*mm+l*m_nngp+k] += 1 + tauSq;
                    }
                }
            }
            F77_NAME(dpotrf)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
            F77_NAME(dpotri)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
            F77_NAME(dsymv)(lower, &m_nngp, &one, &C_predict[threadID*mm], &m_nngp, &c_predict[threadID*m_nngp], &inc, &zero, &tmp_m[threadID*m_nngp], &inc FCONE);
            dcopy_(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &y0[i*m_nngp], &inc);
            vary0[i] = 1 + sigmaSq + tauSq - F77_NAME(ddot)(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &c_predict[threadID*m_nngp], &inc);
            solve_B_F_predict2(&y0[i*m_nngp], vary0[i], n_nngp, nnIndx0, m_nngp, &L0[i*(n_nngp)], sim_cor, i, q);
            for(im = 0; im < mc; im++){
            sum = 0.0;
            for (j = 0; j < n_nngp; j++) {
                sum = sum + L0[i*(n_nngp) + j] * qnorm(unif_eval[n_nngp*im + j] * e[n_nngp*im + j], 0.0, 1.0, 1, 0);
            }
            e_pred[mc*i + im] = pnorm((mvec0[i] - sum)/sqrt(vary0[i]), 0.0, 1.0, 1, 0) * e_prod[im];
            }
        }
            
            
            
            //return stuff
            SEXP result_r, resultName_r;
            int nResultListObjs = 15;
            
            
            
            PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
            PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
            
            
            SET_VECTOR_ELT(result_r, 0, nnIndxLU_r);
            SET_VECTOR_ELT(resultName_r, 0, mkChar("nnIndxLU"));
            
            SET_VECTOR_ELT(result_r, 1, CIndx_r);
            SET_VECTOR_ELT(resultName_r, 1, mkChar("CIndx"));
            
            SET_VECTOR_ELT(result_r, 2, D_r);
            SET_VECTOR_ELT(resultName_r, 2, mkChar("D"));
            
            SET_VECTOR_ELT(result_r, 3, d_r);
            SET_VECTOR_ELT(resultName_r, 3, mkChar("d"));
            
            SET_VECTOR_ELT(result_r, 4, nnIndx_r);
            SET_VECTOR_ELT(resultName_r, 4, mkChar("nnIndx"));
            
            SET_VECTOR_ELT(result_r, 5, L0_r);
            SET_VECTOR_ELT(resultName_r, 5, mkChar("L0"));
            
            SET_VECTOR_ELT(result_r, 6, B_r);
            SET_VECTOR_ELT(resultName_r, 6, mkChar("B"));
            
            SET_VECTOR_ELT(result_r, 7, F_r);
            SET_VECTOR_ELT(resultName_r, 7, mkChar("F"));
            
            SET_VECTOR_ELT(result_r, 8, c_r);
            SET_VECTOR_ELT(resultName_r, 8, mkChar("c"));
            
            SET_VECTOR_ELT(result_r, 9, e_r);
            SET_VECTOR_ELT(resultName_r, 9, mkChar("e"));
            
            SET_VECTOR_ELT(result_r, 10, sim_cor_r);
            SET_VECTOR_ELT(resultName_r, 10, mkChar("sim"));
            
            SET_VECTOR_ELT(result_r, 11, e_prod_r);
            SET_VECTOR_ELT(resultName_r, 11, mkChar("e_prod"));
            
            SET_VECTOR_ELT(result_r, 12, y0_r);
            SET_VECTOR_ELT(resultName_r, 12, mkChar("p.y.0"));
            
            SET_VECTOR_ELT(result_r, 13, vary0_r);
            SET_VECTOR_ELT(resultName_r, 13, mkChar("var.y.0"));
            
            SET_VECTOR_ELT(result_r, 14, e_pred_r);
            SET_VECTOR_ELT(resultName_r, 14, mkChar("predicted_e"));
            
            
            namesgets(result_r, resultName_r);
            
            //unprotect
            UNPROTECT(nProtect);
            
            
            return(result_r);
    }
    
    SEXP Binary_prediction_cholesky_prediction_neighbor_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                                   SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP mvec_r, SEXP unif_eval_r, SEXP mc_r, SEXP coords0_r, SEXP q_r, SEXP nnIndx0_r, SEXP mvec0_r,
                                                   SEXP nnIndxLU_r, SEXP CIndx_r, SEXP D_r, SEXP d_r, SEXP nnIndx_r, SEXP j_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        int sim_number = n_nngp;
        double *sim = REAL(sim_r);
        int tot_length = n_nngp*sim_number;
        double *unif_eval = REAL(unif_eval_r);
        double *mvec = REAL(mvec_r);
        int mc = INTEGER(mc_r)[0];
        double *mvec0 = REAL(mvec0_r);
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        //SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        //SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);
        
        //SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        
        //SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        
        //SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;
        
        //SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);
        
        //SEXP D_sign_r; PROTECT(D_sign_r = allocVector(INTSXP, j_nngp)); nProtect++; D_sign_nngp = INTEGER(D_sign_r);
        nnIndx_nngp = INTEGER(nnIndx_r);
        d_nngp = REAL(d_r);
        
        nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        
        CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        INTEGER(j_r)[0] = j_nngp;
        
        D_nngp = REAL(D_r);
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j_nngp)); nProtect++; double *C = REAL(C_r);
        
        //SEXP e_prod_r; PROTECT(e_prod_r = allocMatrix(REALSXP, mc, 2)); nProtect++; double *e_prod = REAL(e_prod_r);
        SEXP e_prod_r; PROTECT(e_prod_r = allocVector(REALSXP, mc)); nProtect++; double *e_prod = REAL(e_prod_r);
        
        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j_nngp, sizeof(double)); zeros(C, j_nngp);
        
        
        double logDet = binary_updateBF(y_nngp, B_nngp, F_nngp, c, C, D_nngp, d_nngp, nnIndxLU_nngp, nnIndx_nngp, CIndx_nngp, n_nngp, theta, covModel_nngp, nThreads_nngp);
        
        for(int im = 0; im < sim_number; im++){//need to parallel
            solve_B_F(B_nngp, F_nngp, &sim[n_nngp*im], n_nngp, nnIndxLU_nngp, nnIndx_nngp, &sim_cor[n_nngp*im]);
        }
        
        //double *e =(double *) R_alloc(mc*n_nngp, sizeof(double));
        SEXP e_r; PROTECT(e_r = allocMatrix(REALSXP, n_nngp, mc)); nProtect++; double *e = REAL(e_r);
        for(int im = 0; im < mc; im++){//need to parallel
            e_prod[im] = eval_binary_e(&unif_eval[n_nngp*im], mvec, sim_cor, n_nngp, &e[n_nngp*im]);
        }
        
        //prediction
        double *coords0 = REAL(coords0_r);
        int q = INTEGER(q_r)[0];
        
        int *nnIndx0 = INTEGER(nnIndx0_r);
        
        const int inc = 1;
        const double one = 1.0;
        const double zero = 0.0;
        char const *lower = "L";
        int info, j, im;
        double sum;
        
        //parameters
        int sigmaSqIndx, tauSqIndx, phiIndx, nuIndx;
        
        if(corName != "matern"){
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2;
        }else{
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2; nuIndx = 3;
        }
        
        //get max nu
        double nuMax = 0;
        int nb = 0;
        
        if(corName == "matern"){
            if(theta[nuIndx] > nb){
                nb = theta[nuIndx];
            }
            
            nb = 1+static_cast<int>(floor(nuMax));
        }
        
        double *bk = (double *) R_alloc(nThreads_nngp*nb, sizeof(double));
        int mm = m_nngp*m_nngp;
        
        //SEXP c_predict_r; PROTECT(c_predict_r = allocVector(REALSXP, nThreads_nngp*m_nngp)); nProtect++; double *c_predict = REAL(c_r);
        
        //SEXP C_predict_r; PROTECT(C_predict_r = allocVector(REALSXP, nThreads_nngp*mm)); nProtect++; double *C_predict = REAL(C_r);
        //zeros(C_predict, nThreads_nngp*mm);
        //zeros(c_predict, nThreads_nngp*m_nngp);
        
        double *C_predict = (double *) R_alloc(nThreads_nngp*mm, sizeof(double)); zeros(C_predict, nThreads_nngp*mm);
        double *c_predict = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double)); zeros(c_predict, nThreads_nngp*m_nngp);
        //SEXP L_pred_r; PROTECT(L_pred_r = allocVector(REALSXP, q * (1 + n_nngp))); nProtect++; double *L_pred = REAL(L_pred_r);
        
        double *tmp_m  = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double));
        double phi = 0, nu = 0, sigmaSq = 0, tauSq = 0, d;
        int threadID = 0;
        
        SEXP y0_r;
        SEXP vary0_r;
        SEXP L0_r;
        PROTECT(vary0_r = allocMatrix(REALSXP, q, 1)); nProtect++;
        double *vary0 = REAL(vary0_r);
        PROTECT(y0_r = allocMatrix(REALSXP, m_nngp, q)); nProtect++;
        double *y0 = REAL(y0_r);
        PROTECT(L0_r = allocMatrix(REALSXP, n_nngp, q)); nProtect++;
        double *L0 = REAL(L0_r);
        SEXP e_pred_r; PROTECT(e_pred_r = allocMatrix(REALSXP, mc, q)); nProtect++; double *e_pred = REAL(e_pred_r);
        
        
        if(verbose){
            Rprintf("-------------------------------------------------\n");
            Rprintf("\t\tBuilding prediction cholesky\n");
            Rprintf("-------------------------------------------------\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        
        
        
#ifdef _OPENMP
#pragma omp parallel for private(threadID, phi, nu, sigmaSq, tauSq, k, l, d, info, sum, j, im)
#endif
        for(i = 0; i < q; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            phi = theta[phiIndx];
            if(corName == "matern"){
                nu = theta[nuIndx];
            }
            sigmaSq = theta[sigmaSqIndx];
            tauSq = theta[tauSqIndx];
            
            for(k = 0; k < m_nngp; k++){
                d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords0[i], coords0[q+i]);
                c_predict[threadID*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                for(l = 0; l < m_nngp; l++){
                    d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords[nnIndx0[i+q*l]], coords[n_nngp+nnIndx0[i+q*l]]);
                    C_predict[threadID*mm+l*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * (2 * y_nngp[nnIndx0[i+q*l]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                    if(k == l){
                        C_predict[threadID*mm+l*m_nngp+k] += 1 + tauSq;
                    }
                }
            }
            F77_NAME(dpotrf)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
            F77_NAME(dpotri)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
            F77_NAME(dsymv)(lower, &m_nngp, &one, &C_predict[threadID*mm], &m_nngp, &c_predict[threadID*m_nngp], &inc, &zero, &tmp_m[threadID*m_nngp], &inc FCONE);
            dcopy_(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &y0[i*m_nngp], &inc);
            vary0[i] = 1 + sigmaSq + tauSq - F77_NAME(ddot)(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &c_predict[threadID*m_nngp], &inc);
            solve_B_F_predict2(&y0[i*m_nngp], vary0[i], n_nngp, nnIndx0, m_nngp, &L0[i*(n_nngp)], sim_cor, i, q);
            for(im = 0; im < mc; im++){
                sum = 0.0;
                for (j = 0; j < n_nngp; j++) {
                    sum = sum + L0[i*(n_nngp) + j] * qnorm(unif_eval[n_nngp*im + j] * e[n_nngp*im + j], 0.0, 1.0, 1, 0);
                }
                e_pred[mc*i + im] = pnorm((mvec0[i] - sum)/sqrt(vary0[i]), 0.0, 1.0, 1, 0) ;
            }
        }
        
        
        
        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 15;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        SET_VECTOR_ELT(result_r, 0, nnIndxLU_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("nnIndxLU"));
        
        SET_VECTOR_ELT(result_r, 1, CIndx_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("CIndx"));
        
        SET_VECTOR_ELT(result_r, 2, D_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("D"));
        
        SET_VECTOR_ELT(result_r, 3, d_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("d"));
        
        SET_VECTOR_ELT(result_r, 4, nnIndx_r);
        SET_VECTOR_ELT(resultName_r, 4, mkChar("nnIndx"));
        
        SET_VECTOR_ELT(result_r, 5, L0_r);
        SET_VECTOR_ELT(resultName_r, 5, mkChar("L0"));
        
        SET_VECTOR_ELT(result_r, 6, B_r);
        SET_VECTOR_ELT(resultName_r, 6, mkChar("B"));
        
        SET_VECTOR_ELT(result_r, 7, F_r);
        SET_VECTOR_ELT(resultName_r, 7, mkChar("F"));
        
        SET_VECTOR_ELT(result_r, 8, c_r);
        SET_VECTOR_ELT(resultName_r, 8, mkChar("c"));
        
        SET_VECTOR_ELT(result_r, 9, e_r);
        SET_VECTOR_ELT(resultName_r, 9, mkChar("e"));
        
        SET_VECTOR_ELT(result_r, 10, sim_cor_r);
        SET_VECTOR_ELT(resultName_r, 10, mkChar("sim"));
        
        SET_VECTOR_ELT(result_r, 11, e_prod_r);
        SET_VECTOR_ELT(resultName_r, 11, mkChar("e_prod"));
        
        SET_VECTOR_ELT(result_r, 12, y0_r);
        SET_VECTOR_ELT(resultName_r, 12, mkChar("p.y.0"));
        
        SET_VECTOR_ELT(result_r, 13, vary0_r);
        SET_VECTOR_ELT(resultName_r, 13, mkChar("var.y.0"));
        
        SET_VECTOR_ELT(result_r, 14, e_pred_r);
        SET_VECTOR_ELT(resultName_r, 14, mkChar("predicted_e"));
        
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
    SEXP Binary_cholesky_estimation_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                                   SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP mvec_r, SEXP unif_eval_r, SEXP mc_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        int sim_number = n_nngp;
        double *sim = REAL(sim_r);
        int tot_length = n_nngp*sim_number;
        double *unif_eval = REAL(unif_eval_r);
        double *mvec = REAL(mvec_r);
        int mc = INTEGER(mc_r)[0];
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);
        
        SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        //make the neighbor index
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tBuilding neighbor index\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        if(INTEGER(sType_r)[0] == 0){
            mkNNIndx(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        if(INTEGER(sType_r)[0] == 1){
            mkNNIndxTree0(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }else{
            mkNNIndxCB(n_nngp, m_nngp, coords, nnIndx_nngp, d_nngp, nnIndxLU_nngp);
        }
        
        
        SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        for(i = 0, j_nngp = 0; i < n_nngp; i++){//zero should never be accessed
            j_nngp += nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
            if(i == 0){
                CIndx_nngp[n_nngp+i] = 0;
                CIndx_nngp[i] = 0;
            }else{
                CIndx_nngp[n_nngp+i] = nnIndxLU_nngp[n_nngp+i]*nnIndxLU_nngp[n_nngp+i];
                CIndx_nngp[i] = CIndx_nngp[n_nngp+i-1] + CIndx_nngp[i-1];
            }
        }
        
        SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;
        
        SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);
        
        //SEXP D_sign_r; PROTECT(D_sign_r = allocVector(INTSXP, j_nngp)); nProtect++; D_sign_nngp = INTEGER(D_sign_r);
        
        for(i = 0; i < n_nngp; i++){
            for(k = 0; k < nnIndxLU_nngp[n_nngp+i]; k++){
                for(l = 0; l <= k; l++){
                    D_nngp[CIndx_nngp[i]+l*nnIndxLU_nngp[n_nngp+i]+k] = dist2(coords[nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+k]], coords[nnIndx_nngp[nnIndxLU_nngp[i]+l]], coords[n_nngp+nnIndx_nngp[nnIndxLU_nngp[i]+l]]);
                }
            }
        }
        
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j_nngp)); nProtect++; double *C = REAL(C_r);
        
        //SEXP e_prod_r; PROTECT(e_prod_r = allocMatrix(REALSXP, mc, 2)); nProtect++; double *e_prod = REAL(e_prod_r);
        SEXP e_prod_r; PROTECT(e_prod_r = allocVector(REALSXP, mc)); nProtect++; double *e_prod = REAL(e_prod_r);
        
        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j_nngp, sizeof(double)); zeros(C, j_nngp);
        
        
        double logDet = binary_updateBF(y_nngp, B_nngp, F_nngp, c, C, D_nngp, d_nngp, nnIndxLU_nngp, nnIndx_nngp, CIndx_nngp, n_nngp, theta, covModel_nngp, nThreads_nngp);
        
        for(int im = 0; im < sim_number; im++){//need to parallel
            solve_B_F(B_nngp, F_nngp, &sim[n_nngp*im], n_nngp, nnIndxLU_nngp, nnIndx_nngp, &sim_cor[n_nngp*im]);
        }
        
        //double *e =(double *) R_alloc(mc*n_nngp, sizeof(double));
        SEXP e_r; PROTECT(e_r = allocMatrix(REALSXP, n_nngp, mc)); nProtect++; double *e = REAL(e_r);
        for(int im = 0; im < mc; im++){//need to parallel
            e_prod[im] = eval_binary_e(&unif_eval[n_nngp*im], mvec, sim_cor, n_nngp, &e[n_nngp*im]);
        }
        
        
        //return stuff
               SEXP result_r, resultName_r;
        int nResultListObjs = 3;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        SET_VECTOR_ELT(result_r, 0, e_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("e"));
        
        SET_VECTOR_ELT(result_r, 1, sim_cor_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("sim"));
        
        SET_VECTOR_ELT(result_r, 2, e_prod_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("e_prod"));
        
        
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
    SEXP Binary_cholesky_estimation_neighbor_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                                            SEXP sType_r, SEXP nThreads_r, SEXP verbose_r, SEXP sim_r, SEXP mvec_r, SEXP unif_eval_r, SEXP mc_r,
                                                            SEXP nnIndxLU_r, SEXP CIndx_r, SEXP D_r, SEXP d_r, SEXP nnIndx_r, SEXP j_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        int sim_number = n_nngp;
        double *sim = REAL(sim_r);
        int tot_length = n_nngp*sim_number;
        double *unif_eval = REAL(unif_eval_r);
        double *mvec = REAL(mvec_r);
        int mc = INTEGER(mc_r)[0];
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tModel description\n");
            Rprintf("----------------------------------------\n");
            Rprintf("Using %i nearest neighbors.\n\n", m_nngp);
#ifdef _OPENMP
            Rprintf("\nSource compiled with OpenMP support and model fit using %i thread(s).\n", nThreads_nngp);
#else
            Rprintf("\n\nSource not compiled with OpenMP support.\n");
#endif
        }
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //allocated for the nearest neighbor index vector (note, first location has no neighbors).
        int nIndx = static_cast<int>(static_cast<double>(1+m_nngp)/2*m_nngp+(n_nngp-m_nngp-1)*m_nngp);
        //SEXP nnIndx_r; PROTECT(nnIndx_r = allocVector(INTSXP, nIndx)); nProtect++; nnIndx_nngp = INTEGER(nnIndx_r);
        //SEXP d_r; PROTECT(d_r = allocVector(REALSXP, nIndx)); nProtect++; d_nngp = REAL(d_r);
        
        //SEXP nnIndxLU_r; PROTECT(nnIndxLU_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        
        //SEXP CIndx_r; PROTECT(CIndx_r = allocVector(INTSXP, 2*n_nngp)); nProtect++; CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        
        //SEXP j_r; PROTECT(j_r = allocVector(INTSXP, 1)); nProtect++; INTEGER(j_r)[0] = j_nngp;
        
        //SEXP D_r; PROTECT(D_r = allocVector(REALSXP, j_nngp)); nProtect++; D_nngp = REAL(D_r);
        
        //SEXP D_sign_r; PROTECT(D_sign_r = allocVector(INTSXP, j_nngp)); nProtect++; D_sign_nngp = INTEGER(D_sign_r);
        nnIndx_nngp = INTEGER(nnIndx_r);
        d_nngp = REAL(d_r);
        
        nnIndxLU_nngp = INTEGER(nnIndxLU_r); //first column holds the nnIndx index for the i-th location and the second columns holds the number of neighbors the i-th location has (the second column is a bit of a waste but will simplifying some parallelization).
        
        
        CIndx_nngp = INTEGER(CIndx_r); //index for D and C.
        INTEGER(j_r)[0] = j_nngp;
        
        D_nngp = REAL(D_r);
        
        if(verbose){
            Rprintf("----------------------------------------\n");
            Rprintf("\tCalculationg the approximate Cholesky Decomposition\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        SEXP B_r; PROTECT(B_r = allocVector(REALSXP, nIndx)); nProtect++; double *B_nngp = REAL(B_r);
        
        SEXP F_r; PROTECT(F_r = allocVector(REALSXP, n_nngp)); nProtect++; double *F_nngp = REAL(F_r);
        
        SEXP c_r; PROTECT(c_r = allocVector(REALSXP, nIndx)); nProtect++; double *c = REAL(c_r);
        
        SEXP C_r; PROTECT(C_r = allocVector(REALSXP, j_nngp)); nProtect++; double *C = REAL(C_r);
        
        //SEXP e_prod_r; PROTECT(e_prod_r = allocMatrix(REALSXP, mc, 2)); nProtect++; double *e_prod = REAL(e_prod_r);
        SEXP e_prod_r; PROTECT(e_prod_r = allocVector(REALSXP, mc)); nProtect++; double *e_prod = REAL(e_prod_r);
        
        SEXP sim_cor_r; PROTECT(sim_cor_r = allocVector(REALSXP, tot_length)); nProtect++; double *sim_cor = REAL(sim_cor_r);
        
        //double *c =(double *) R_alloc(nIndx, sizeof(double));
        //double *C = (double *) R_alloc(j_nngp, sizeof(double)); zeros(C, j_nngp);
        
        
        double logDet = binary_updateBF(y_nngp, B_nngp, F_nngp, c, C, D_nngp, d_nngp, nnIndxLU_nngp, nnIndx_nngp, CIndx_nngp, n_nngp, theta, covModel_nngp, nThreads_nngp);
        
        for(int im = 0; im < sim_number; im++){//need to parallel
            solve_B_F(B_nngp, F_nngp, &sim[n_nngp*im], n_nngp, nnIndxLU_nngp, nnIndx_nngp, &sim_cor[n_nngp*im]);
        }
        
        //double *e =(double *) R_alloc(mc*n_nngp, sizeof(double));
        SEXP e_r; PROTECT(e_r = allocMatrix(REALSXP, n_nngp, mc)); nProtect++; double *e = REAL(e_r);
        for(int im = 0; im < mc; im++){//need to parallel
            e_prod[im] = eval_binary_e(&unif_eval[n_nngp*im], mvec, sim_cor, n_nngp, &e[n_nngp*im]);
        }
        
        
        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 3;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        SET_VECTOR_ELT(result_r, 0, e_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("e"));
        
        SET_VECTOR_ELT(result_r, 1, sim_cor_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("sim"));
        
        SET_VECTOR_ELT(result_r, 2, e_prod_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("e_prod"));
        
        
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
    SEXP Binary_cholesky_prediction_neighbor_cpp(SEXP y_r, SEXP n_r, SEXP m_r, SEXP coords_r, SEXP covModel_r, SEXP sigmaSqStarting_r,SEXP tauSqStarting_r, SEXP phiStarting_r, SEXP nuStarting_r, 
                                                 SEXP nThreads_r, SEXP verbose_r, SEXP unif_eval_r, SEXP mc_r, SEXP coords0_r, SEXP q_r, SEXP nnIndx0_r, SEXP mvec0_r,
                                                 SEXP sim_cor_r, SEXP e_r){
        
        int i, k, l, nProtect=0;
        
        
        //get args
        y_nngp = REAL(y_r);
        n_nngp = INTEGER(n_r)[0];
        m_nngp = INTEGER(m_r)[0];
        double *coords = REAL(coords_r);
        covModel_nngp = INTEGER(covModel_r)[0];
        std::string corName = getCorName(covModel_nngp);
        
        nThreads_nngp = INTEGER(nThreads_r)[0];
        int verbose = INTEGER(verbose_r)[0];
        
        double *unif_eval = REAL(unif_eval_r);
        int mc = INTEGER(mc_r)[0];
        double *mvec0 = REAL(mvec0_r);
        double *sim_cor = REAL(sim_cor_r);
        double *e = REAL(e_r);
        
        
        int sim_number = n_nngp;
        int tot_length = n_nngp*sim_number;
        
        
        
#ifdef _OPENMP
        omp_set_num_threads(nThreads_nngp);
#else
        if(nThreads_nngp > 1){
            warning("n.omp.threads > %i, but source not compiled with OpenMP support.", nThreads_nngp);
            nThreads_nngp = 1;
        }
#endif
        
        //parameters
        int nTheta;
        
        if(corName != "matern"){
            nTheta = 3;//sigma^2 = 0, tau^2 = 1, phi = 2
        }else{
            nTheta = 4;//sigma^2 = 0, tau^2 = 1, phi = 2, nu = 3;
        }
        //starting
        double *theta = (double *) R_alloc (nTheta, sizeof(double));
        
        theta[0] = REAL(sigmaSqStarting_r)[0];
        theta[1] = REAL(tauSqStarting_r)[0];
        theta[2] = REAL(phiStarting_r)[0];
        
        
        if(corName == "matern"){
            theta[3] = REAL(nuStarting_r)[0];
        }
        
        //prediction
        double *coords0 = REAL(coords0_r);
        int q = INTEGER(q_r)[0];
        
        int *nnIndx0 = INTEGER(nnIndx0_r);
        
        const int inc = 1;
        const double one = 1.0;
        const double zero = 0.0;
        char const *lower = "L";
        int info, j, im;
        double sum;
        
        //parameters
        int sigmaSqIndx, tauSqIndx, phiIndx, nuIndx;
        
        if(corName != "matern"){
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2;
        }else{
            sigmaSqIndx = 0; tauSqIndx = 1; phiIndx = 2; nuIndx = 3;
        }
        
        //get max nu
        double nuMax = 0;
        int nb = 0;
        
        if(corName == "matern"){
            if(theta[nuIndx] > nb){
                nb = theta[nuIndx];
            }
            
            nb = 1+static_cast<int>(floor(nuMax));
        }
        
        double *bk = (double *) R_alloc(nThreads_nngp*nb, sizeof(double));
        int mm = m_nngp*m_nngp;
        
        double *C_predict = (double *) R_alloc(nThreads_nngp*mm, sizeof(double)); zeros(C_predict, nThreads_nngp*mm);
        double *c_predict = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double)); zeros(c_predict, nThreads_nngp*m_nngp);

        
        double *tmp_m  = (double *) R_alloc(nThreads_nngp*m_nngp, sizeof(double));
        double phi = 0, nu = 0, sigmaSq = 0, tauSq = 0, d;
        int threadID = 0;
        
        SEXP y0_r;
        SEXP vary0_r;
        SEXP L0_r;
        
        PROTECT(vary0_r = allocMatrix(REALSXP, q, 1)); nProtect++;
        double *vary0 = REAL(vary0_r);
        PROTECT(y0_r = allocMatrix(REALSXP, m_nngp, q)); nProtect++;
        double *y0 = REAL(y0_r);
        PROTECT(L0_r = allocMatrix(REALSXP, n_nngp, q)); nProtect++;
        double *L0 = REAL(L0_r);
        SEXP e_pred_r; PROTECT(e_pred_r = allocMatrix(REALSXP, mc, q)); nProtect++; double *e_pred = REAL(e_pred_r);
        
        
        if(verbose){
            Rprintf("-------------------------------------------------\n");
            Rprintf("\t\tBuilding prediction cholesky\n");
            Rprintf("-------------------------------------------------\n");
#ifdef Win32
            R_FlushConsole();
#endif
        }
        
        
        
        
        
#ifdef _OPENMP
#pragma omp parallel for private(threadID, phi, nu, sigmaSq, tauSq, k, l, d, info, sum, j, im)
#endif
        for(i = 0; i < q; i++){
#ifdef _OPENMP
            threadID = omp_get_thread_num();
#endif
            phi = theta[phiIndx];
            if(corName == "matern"){
                nu = theta[nuIndx];
            }
            sigmaSq = theta[sigmaSqIndx];
            tauSq = theta[tauSqIndx];
            
            for(k = 0; k < m_nngp; k++){
                d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords0[i], coords0[q+i]);
                c_predict[threadID*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                for(l = 0; l < m_nngp; l++){
                    d = dist2(coords[nnIndx0[i+q*k]], coords[n_nngp+nnIndx0[i+q*k]], coords[nnIndx0[i+q*l]], coords[n_nngp+nnIndx0[i+q*l]]);
                    C_predict[threadID*mm+l*m_nngp+k] = (2 * y_nngp[nnIndx0[i+q*k]] - 1) * (2 * y_nngp[nnIndx0[i+q*l]] - 1) * sigmaSq*spCor(d, phi, nu, covModel_nngp, &bk[threadID*nb]);
                    if(k == l){
                        C_predict[threadID*mm+l*m_nngp+k] += 1 + tauSq;
                    }
                }
            }
            F77_NAME(dpotrf)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotrf failed\n");}
            F77_NAME(dpotri)(lower, &m_nngp, &C_predict[threadID*mm], &m_nngp, &info FCONE); if(info != 0){error("c++ error: dpotri failed\n");}
            F77_NAME(dsymv)(lower, &m_nngp, &one, &C_predict[threadID*mm], &m_nngp, &c_predict[threadID*m_nngp], &inc, &zero, &tmp_m[threadID*m_nngp], &inc FCONE);
            dcopy_(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &y0[i*m_nngp], &inc);
            vary0[i] = 1 + sigmaSq + tauSq - F77_NAME(ddot)(&m_nngp, &tmp_m[threadID*m_nngp], &inc, &c_predict[threadID*m_nngp], &inc);
            solve_B_F_predict2(&y0[i*m_nngp], vary0[i], n_nngp, nnIndx0, m_nngp, &L0[i*(n_nngp)], sim_cor, i, q);
            for(im = 0; im < mc; im++){
                sum = 0.0;
                for (j = 0; j < n_nngp; j++) {
                    sum = sum + L0[i*(n_nngp) + j] * qnorm(unif_eval[n_nngp*im + j] * e[n_nngp*im + j], 0.0, 1.0, 1, 0);
                }
                e_pred[mc*i + im] = pnorm((mvec0[i] - sum)/sqrt(vary0[i]), 0.0, 1.0, 1, 0) ;
            }
        }
        
        
        
        //return stuff
        SEXP result_r, resultName_r;
        int nResultListObjs = 4;
        
        
        
        PROTECT(result_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        PROTECT(resultName_r = allocVector(VECSXP, nResultListObjs)); nProtect++;
        
        
        
        
        
        SET_VECTOR_ELT(result_r, 0, L0_r);
        SET_VECTOR_ELT(resultName_r, 0, mkChar("L0"));
        
        SET_VECTOR_ELT(result_r, 1, y0_r);
        SET_VECTOR_ELT(resultName_r, 1, mkChar("p.y.0"));
        
        SET_VECTOR_ELT(result_r, 2, vary0_r);
        SET_VECTOR_ELT(resultName_r, 2, mkChar("var.y.0"));
        
        SET_VECTOR_ELT(result_r, 3, e_pred_r);
        SET_VECTOR_ELT(resultName_r, 3, mkChar("predicted_e"));
        
        
        namesgets(result_r, resultName_r);
        
        //unprotect
        UNPROTECT(nProtect);
        
        
        return(result_r);
    }
}



