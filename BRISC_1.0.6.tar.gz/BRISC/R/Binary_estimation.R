Binary_estimation <- function(coords, y, x = NULL, beta = NULL, sigma.sq = 1, tau.sq = 0.1, phi = 1, nu = 1.5,
                              n.neighbors = 3, n_omp = 1, order = "Sum_coords", cov.model = "exponential", 
                              search.type = "tree", mc_iter = NULL, stabilization = NULL, verbose = TRUE, ordering = NULL, neighbor = NULL, tol = 12
){
  n <- nrow(coords)
  if(is.null(x)){
    x <- matrix(1, nrow = n, ncol = 1)
  }
  p <- ncol(x)
  ##Coords and ordering
  if(!is.matrix(coords)){stop("error: coords must n-by-2 matrix of xy-coordinate locations")}
  if(order == "AMMD" && length(y) < 65){stop("error: Number of data points must be atleast 65 to use AMMD")}
  if(ncol(coords) != 2 || nrow(coords) != n){
    stop("error: either the coords have more than two columns or the number of rows is different than
         data used in the model formula")
  }
  if(is.matrix(y) & ncol(as.matrix(y)) > 1)
  {stop("error: BRISC handles only univariate response. You have used a y (response) with more than one column.
          The ordering of inputs x (covariates) and y (response) in BRISC_estimation has been changed BRISC 0.2.0 onwards.
          Did you mean x (covaiates) instead of y (response) by the multivariatte input?
          Please check the new documentation with ?BRISC_estimation.")
    
  }
  if(is.null(beta)){beta <- rep(0, p)}
  if(length(beta) != p){stop("error: beta nust have same number of elements as the columns of x")}
  
  coords <- round(coords, tol)
  x <- round(x, tol)
  y <- round(y, tol)
  
  if(tau.sq < 0 ){stop("error: tau.sq must be non-negative")}
  if(sigma.sq < 0 ){stop("error: sigma.sq must be non-negative")}
  if(phi < 0 ){stop("error: phi must be non-negative")}
  if(nu < 0 ){stop("error: nu must be non-negative")}
  
  if(is.null(ordering)){
    if(order != "AMMD" && order != "Sum_coords"){
      stop("error: Please insert a valid ordering scheme choice given by 1 or 2.")
    }
    if(verbose == TRUE){
      cat(paste(("----------------------------------------"), collapse="   "), "\n"); cat(paste(("\tOrdering Coordinates"), collapse="   "), "\n")
    }
    if(order == "AMMD"){ord <- orderMaxMinLocal(coords)}
    if(order == "Sum_coords"){ord <- order(coords[,1] + coords[,2])}
  }
  if(!is.null(ordering)){
    ord <- ordering
  }
  coords <- coords[ord,]
  
  ##Input data and ordering
  X <- x[ord,,drop=FALSE]
  y <- y[ord]
  
  
  
  ##Covariance model
  cov.model.names <- c("exponential","spherical","matern","gaussian")
  cov.model.indx <- which(cov.model == cov.model.names) - 1
  storage.mode(cov.model.indx) <- "integer"
  
  
  ##Stabilization
  if(is.null(stabilization)){
    if(cov.model == "exponential"){
      stabilization = FALSE
    }
    if(cov.model != "exponential"){
      stabilization = TRUE
    }
  }
  
  if(!isTRUE(stabilization)){
    if(cov.model != "exponential"){
      warning('We recommend using stabilization for spherical, Matern and Gaussian covariance model')
    }
  }
  
  if(isTRUE(stabilization)){
    taus <- 10^-6 * sigma.sq
    tau.sq <- tau.sq + taus
    if(verbose == TRUE) cat(paste(("----------------------------------------"), collapse="   "), "\n"); cat(paste(("\tUsing Stabilization"), collapse="   "), "\n"); cat(paste(("----------------------------------------"), collapse="   "), "\n")
  }
  
  
  ##Initial values
  if(cov.model!="matern"){
    initiate <- c(sigma.sq, tau.sq, phi)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi")
  }
  else{
    initiate <- c(sigma.sq, tau.sq, phi, nu)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi", "nu")}
  
  sigma.sq.starting <- sigma.sq
  tau.sq.starting <- tau.sq
  phi.starting <- phi
  nu.starting <- nu
  
  storage.mode(sigma.sq.starting) <- "double"
  storage.mode(tau.sq.starting) <- "double"
  storage.mode(phi.starting) <- "double"
  storage.mode(nu.starting) <- "double"
  
  
  ##Search type
  search.type.names <- c("brute", "tree", "cb")
  if(!search.type %in% search.type.names){
    stop("error: specified search.type '",search.type,"' is not a valid option; choose from ", paste(search.type.names, collapse=", ", sep="") ,".")
  }
  search.type.indx <- which(search.type == search.type.names)-1
  storage.mode(search.type.indx) <- "integer"
  
  
  ##Option for Multithreading if compiled with OpenMp support
  n.omp.threads <- as.integer(n_omp)
  storage.mode(n.omp.threads) <- "integer"
  
  
  ##type conversion
  storage.mode(y) <- "double"
  storage.mode(X) <- "double"
  storage.mode(p) <- "integer"
  storage.mode(n) <- "integer"
  storage.mode(coords) <- "double"
  storage.mode(n.neighbors) <- "integer"
  storage.mode(verbose) <- "integer"
  
  if(is.null(mc_iter)){mc_iter <- 100}
  storage.mode(mc_iter) <- "integer"
  unif_eval <- matrix(runif(mc_iter * n), n, mc_iter)
  mvec <- (2 * y - 1) * X %*% beta
  
  p1<- proc.time()
  
  ##estimtion
  #result <- .Call("Binary_prediction_cholesky_estimation_cpp", y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, tau.sq.starting, phi.starting, nu.starting, search.type.indx, n.omp.threads, verbose, diag(n), mvec, unif_eval, mc_iter)
  #result <- .Call("BRISC_cholesky_cpp", y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, 1.0 + tau.sq.starting, phi.starting, nu.starting, search.type.indx, n.omp.threads, verbose)
  p2 <- proc.time()
  
  
  p1<- proc.time()
  
  ##estimtion
  if(is.null(neighbor)){
    result <- .Call("Binary_cholesky_estimation_cpp", y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, tau.sq.starting, phi.starting, nu.starting, search.type.indx, n.omp.threads, verbose, diag(n), mvec, unif_eval, mc_iter)
  }
  
  if(!is.null(neighbor)){
    nnIndxLU <- neighbor$nnIndxLU
    storage.mode(nnIndxLU) <- "integer"
    CIndx <- neighbor$CIndx
    storage.mode(CIndx) <- "integer"
    D <- neighbor$D
    storage.mode(D) <- "double"
    d <- neighbor$d
    storage.mode(d) <- "double"
    nnIndx <- neighbor$nnIndx
    storage.mode(nnIndx) <- "integer"
    j <- neighbor$j
    storage.mode(j) <- "integer"
    
    result <- .Call("Binary_cholesky_estimation_neighbor_cpp", y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, tau.sq.starting, phi.starting, nu.starting, search.type.indx, n.omp.threads, verbose, diag(n), mvec, unif_eval, 
                    mc_iter,
                    nnIndxLU, CIndx, D, d, nnIndx, j, PACKAGE = "BRISC")
    
  }
  #result <- .Call("BRISC_cholesky_cpp", y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, 1.0 + tau.sq.starting, phi.starting, nu.starting, search.type.indx, n.omp.threads, verbose)
  p2 <- proc.time()
  
  
  result_list <- list()
  result_list$result <- result
  result_list$coords <- coords
  result_list$y <- y
  result_list$unif_eval <- unif_eval
  result_list
}
