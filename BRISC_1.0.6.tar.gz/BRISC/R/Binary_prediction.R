Binary_prediction <- function(estimation_out, coords.0, X.0 = NULL, beta = NULL, sigma.sq = 1, tau.sq = 0.1, phi = 1, nu = 1.5,
                              n.neighbors = 3, n_omp = 1, order = "Sum_coords", cov.model = "exponential", 
                              search.type = "tree", mc_iter = NULL, verbose = TRUE, tol = 12
){
  coords <- estimation_out$coords
  n <- nrow(coords)
  storage.mode(n) <- "integer"
  if(tau.sq < 0 ){stop("error: tau.sq must be non-negative")}
  if(sigma.sq < 0 ){stop("error: sigma.sq must be non-negative")}
  if(phi < 0 ){stop("error: phi must be non-negative")}
  if(nu < 0 ){stop("error: nu must be non-negative")}
  
  
  ##Covariance model
  cov.model.names <- c("exponential","spherical","matern","gaussian")
  cov.model.indx <- which(cov.model == cov.model.names) - 1
  storage.mode(cov.model.indx) <- "integer"
  
  
  
  ##Initial values
  if(cov.model!="matern"){
    initiate <- c(sigma.sq, tau.sq, phi)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi")
  }
  else{
    initiate <- c(sigma.sq, tau.sq, phi, nu)
    names(initiate) <- c("sigma.sq", "tau.sq", "phi", "nu")}
  
  sigma.sq.starting <- sigma.sq
  tau.sq.starting <- tau.sq
  phi.starting <- phi
  nu.starting <- nu
  
  storage.mode(sigma.sq.starting) <- "double"
  storage.mode(tau.sq.starting) <- "double"
  storage.mode(phi.starting) <- "double"
  storage.mode(nu.starting) <- "double"
  
  
  ##Option for Multithreading if compiled with OpenMp support
  n.omp.threads <- as.integer(n_omp)
  storage.mode(n.omp.threads) <- "integer"
  
  
  ##type conversion
  storage.mode(coords) <- "double"
  storage.mode(n.neighbors) <- "integer"
  storage.mode(verbose) <- "integer"
  
  if(is.null(mc_iter)){mc_iter <- 100}
  storage.mode(mc_iter) <- "integer"
  unif_eval <- estimation_out$unif_eval
  
  n.0 <- nrow(coords.0)
  if(is.null(X.0)){
    X.0 <- matrix(1, nrow = n.0, ncol = 1)
  }
  
  coords.0 <- round(coords.0, tol)
  X.0 <- round(X.0, tol)
  mvec.0 <- X.0 %*% beta
  
  nn.indx.0 <- nn2(coords, coords.0, k=n.neighbors)$nn.idx-1
  q <- nrow(coords.0)
  storage.mode(q) <- "integer"
  storage.mode(nn.indx.0) <- "integer"
  
  result <- .Call("Binary_cholesky_prediction_neighbor_cpp", estimation_out$y, n, n.neighbors, coords, cov.model.indx, sigma.sq.starting, tau.sq.starting, phi.starting, nu.starting, 
                  n.omp.threads, verbose, unif_eval, 
                  mc_iter, coords.0, q, nn.indx.0, mvec.0, estimation_out$result$sim, estimation_out$result$e,
                  PACKAGE = "BRISC")
  
  result_list <- list()
  result_list$result <- result
  return(result_list)
}
